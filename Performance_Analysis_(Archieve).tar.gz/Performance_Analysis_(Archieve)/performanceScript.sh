# A script for performace anlyasis of tock-CSP using FDR, translated TA and a handwritten single TA with UPPAAL.
#!/bin/bash

#Specify format for the time, %lR for long format like 0m0.037s, while %R for short format like 0.039s
TIMEFORMAT=%R

#example/*/FDR/*/p0_1_s1.csp
#for i in Performance/*.csp ; do
for i in example/*/FDR/*/* ; do 
    #Get the time 10 times and compute the average
    sum_tcsp=0.0
    for value in {1..10}
    do
        # Get the time
     tcsp="$(time (refines --format json  "$i".csp 1>  output/"$(basename $i)"fdr.json)  2>&1 1>/dev/null)"

        # for each run write the result into a file timing
        echo $(basename $i) " = " $tcsp  >> timingExamples
        
        #Update sum, uses the bc for floats operations, bash is restricted to integer operations.
        sum_tcsp=$(bc <<< "scale=5; $sum_tcsp + $tcsp")
        #sum='$sum + $tcsp | bc'
    done
     
    #Write the average into a file timing
    echo "average" $(basename $i) " = " $(bc <<< "scale=5; $sum_tcsp / 10")  >> timingExamples    

done

# For the translated TA of Uppaal model
for i in example/*/Uppaal/*/* ; do

    #Get the time 10 times and compute the average
    sum_ttTA=0.0
    for value in {1..10}
    do
        # Get the time for the translated TA, ttTA.
        ttTA="$(time ( ./verifyta -t1 -X  output/"$(basename $i)"uppaal  "$i" )  2>&1 1>/dev/null)"

        # for each run write the result into a file timing
        echo $(basename $i) " = " $ttTA  >> timingExamples
        
        #Update sum, uses the bc for floats operations, bash is restricted to integer operations.
        sum_ttTA=$(bc <<< "scale=5; $sum_ttTA + $ttTA")

    done
     
    #Write the average into a file timing
    echo "average" $(basename $i) " = " $(bc <<< "scale=5; $sum_ttTA / 10")  >> timingExamples

done

# For the single TA of Uppaal model
#for i in Performance/*SingleTA.xml ; do

    # Get the time
#    tSTA="$(time ( ./verifyta -t1 -X  Performance/output/$"(basename $i)"uppaal  "$i" )  2>&1 1>/dev/null)"

    # for each run write the result into a file
#    echo $(basename $i) " = " $tSTA  >> Performance/timing
#done

#Display the timing
cat timingExamples

#Store the average in another file timingExamplesAvgs
grep  'average'   < timingExamples  > timingExamplesAvgs    



