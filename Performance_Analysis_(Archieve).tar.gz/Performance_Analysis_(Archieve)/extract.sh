

#((sed 's|</|\n|g' | grep -o -P 'average*') | sed 's|\n+|,|g' )   <timingExamples  >timingExamplesAvg    

grep  'average'   < timingExamples  > timingExamplesAvg    

#((sed 's|</|\n|g' | grep -o -P 'average*') )   < timingExamples  > timingExamplesAvg    
