import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import TA
import Data.List.Split as S
import System.Environment   
import System.Directory  
import System.IO  
import Data.List 


{-- Todo for improvement:
--traceTA.hs: Prelude.!!: index too large
--}

-- To revise this later?
main = do 
        [fEdge, fTrans, dr] <- getArgs
        sEdge  <- readFile fEdge
        sTrans <- readFile fTrans        
        appendFile  (dr ++ "/traceRes") (traceGen sTrans sEdge)

----------------------------------------------------------------------------------------------
-- Function for assembling the traces
traceGen :: String -> String -> String
traceGen    trans edges     =  if null traceUppaal then "" else "[" ++ ishowListSt traceUppaal ++ "]\n"
                              where 
                                    traceUppaal = removeExCh (removeCon (removeQE subs))
                                    subs        = isubs (map head (map (words) (lines trans))) (lines edges)


genSubList :: [String] -> String
genSubList    []       =  ""
genSubList    es       =  ("[" ++ (ishowListSt es)  ++ "]\n") -- ++ (genSubList (init es))


-- Substitutes all event nos with event names es using the event mapppings emaps from the FDR trace
isubs :: [String]  -> [String]                  -> [String]
isubs    es           []                        =  es
isubs    es           [y]                       =  es
isubs    es           (edgeNo:eventName:emaps)  =  isubs (ireplace edgeNo eventName es) emaps

-- Replacement each event with its corresponding name
ireplace :: String -> String -> [String] -> [String]
ireplace    old       new       []       =  []
ireplace    old       new       (z:zs)   =  if(old == z) then new:(ireplace old new zs)
                                            else z:(ireplace old new zs)

-- To update: to combine the following three functions into one
-- Remove connectors, TA events startID, finishID
removeCon :: [String] -> [String]
removeCon    []        = []
removeCon    (x:xs)    = if (take 5 x) `elem` ["start", "finis"]  then removeCon xs
                         else [x] ++ removeCon xs


-- Remove events with question mark, ticks except the last one
removeQE :: [String]       -> [String]
removeQE    []             = []
removeQE    ["finishID0!"] = ["tick"]   -- replace only finishID0 with tick.
removeQE    ["tick!"]      = ["tick"]   -- if tick comes last, as in the case of monitor
--- removeQE    ["tick!"] = ["tick"]
removeQE    (x:xs)    | ((last x) == '?')                     = removeQE xs  -- Remove
                      | (x == "tau")                          = removeQE xs  -- remove tau
                      | (x == "itau!")                        = removeQE xs  -- remove tau                      
                      | (x == "tick!")                        = removeQE xs  -- remove tick except the last one
--     todo             | (x == "itick!")                      = removeQE xs  -- remove tick except the last one
                      | ((take 6 (reverse x)) == "!cnys_")    = removeQE xs  -- removes synch events, like e2_sync
                      | ((take 8 (reverse x)) == "!tprtni_")  = removeQE xs  --removes interrupt connectors, e2_intrpt
                      | otherwise                             = [init x] ++ removeQE xs


-- Todo: to combine with the removeQE
-- Renamed back initials of external choice and sync points                       
removeExCh :: [String] -> [String]
removeExCh    []        = []
removeExCh    (x:xs)    = if (take 5 (reverse x)) `elem` ["hcxe_"]  then removeExCh xs
                          else [x] ++ removeExCh xs


