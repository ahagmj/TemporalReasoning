#-- Bash script that provides interface for interacting with the collections of programs for generating and comparing FDR and UPPAAL traces.
#!/bin/bash


# --------------------------------------------------------------------------------------
function analysis(){
    #--------------------------------------------------------
    # Trace analysis script
    source script.sh

    #--------------------------------------------------------
    #Displays final result

    echo "*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*"
    echo "*~~~~~~~~~~~~~~~~~~~~~~~ RESULT ~~~~~~~~~~~~~~~~~~~~~~~~~*"
    cat GenFiles/traceComparisonsAll
}

#Set trace size 
traceSize=3

# --------------------------------------------------------------------------------------
#Displays the manual page
cat manPage


#---------------------------------------------------------------------------------------
# begining of the input from the terminal
while :
do
    # option command can be load/process, commandArg can be fileName/processNo or all to chose all processes
    # read input from the terminal
    read -e -p 'input <-- ' optionCommand commandArg

    case "$optionCommand" in
        # loads a file for AST
        load )
            # check if the file name is not empty
            if [ -z "$commandArg" ]
            then
                echo "File name is empty"
            else
                echo "loading file " $commandArg "..."

                # Delete the previous result, if any.
                rm -rf GenFiles
                echo "Previous result has been removed."
                
                # construct a Haskell file from the AST
                # commandArg provides the file name to load        
                runhaskell fileConstructor.hs $commandArg $traceSize

                # run the constructed haskell file to generate both CSP and TA files for the process.
                runhaskell "$commandArg".hs
                
                # generates and analyses the traces using the function analysis, defined above.
                analysis
            fi
            ;;
        # analyse a process (AST) provided in the common prompt   
        analyse )
            # check if the file name is not empty
            if [ -z "$commandArg" ]
            then
                echo "Process is empty"
            else
                echo "analysing process " $commandArg "..."

                # Delete the previous result, if any.
                rm -rf GenFiles
                echo "Previous result has been removed."                
                
                # construct a Haskell file from the AST
                # copy the Haskell structure from fileFrame and attach the AST from the commandline
#                runhaskell fileConstructorFromText.hs $commandArg
                cat fileFrame    > prompt.hs
                echo "           genFiles $traceSize  [ $commandArg ]"  >> prompt.hs

                # run the constructed haskell file to generate both CSP and TA files for the process.
                runhaskell prompt.hs
                
                # generates and analyses the traces using the function analysis, defined above.
                analysis
            fi
            ;;


        # select a process from the provided proceses, including all
        process )
            # check command argument
            case "$commandArg" in
            
                ""  )
                    echo "Process number is not needed"
                    ;;
                
                all )
                
                    # Delete the previous result, if any.
                    rm -rf GenFiles
                    echo "Previous result has been removed."                    

                    #runs all the provided process
                    echo "Analysing all the provided processes ..."
                    runhaskell tests_choice.hs "$commandArg"  $traceSize
                    
                    # generates and analyses the traces using the function analysis, defined above.
                    analysis

                    ;;
                
                *   )  
                
                    # Delete the previous result, if any.
                    rm -rf GenFiles
                    echo "Previous result has been removed."
                          
                    echo "Analysing process" $commandArg
                    runhaskell tests_choice.hs $commandArg  $traceSize   
                    
                    # generates and analyses the traces using the function analysis, defined above.
                    analysis
                    
                    ;;       
            esac
            ;;                

        # Display table of the provided processes
        processes )
            cat table
            ;;

        # set trace size
        tracesize )
            if [ -z "$commandArg" ]
                then
                echo "Current trace length is $traceSize"
            else
                traceSize=$commandArg   # $(($commandArg))
                echo "Trace length is set to $traceSize"
            fi    
            ;;

        # display manual page
        man )
            cat manPage
            ;;
                
        * )
            echo "Invalid command" #, please check again." #, valid commands are ..."
            #exit 0
            ;;
        
        esac

done
# End of input terminal


