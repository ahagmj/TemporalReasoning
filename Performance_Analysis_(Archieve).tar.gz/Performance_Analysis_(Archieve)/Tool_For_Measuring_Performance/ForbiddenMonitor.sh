#TODO
#------------------------------------------------------------
#  File description:
#  This Bash script file verifies traces with an additional forbidden initial event.
#  For the purpose of exhaustive testing of traces with an additional forbidden initials.

#------------------------------------------------------------
#Reads and exends the FDR traces with a forbidden initial and generates their corresponding TA monitors
for i in GenFiles/p* ; do
     runhaskell extendTraceWithForbiddenInits.hs  $i/FDR/traceResFDR  $i/FDR/events  $i/monitor/*TA.xml  $i  $traceSize
done


#Invokes UPPAAL to verify the generated TA monitors for the traces with forbidden initials
for i in GenFiles/p*/ForbiddeInits/monitorTrace*.xml ;  do

      #Invokes UPPAAL engine for verifying traces with an added forbidden initials
      ./verifyta -t1 -X  "$i"_result    $i 


      #Extract edges from the trace file of UPPAAL
      ((sed 's|</|\n|g' | grep -o -P '(?<=<sync>).*|(?<=<edge id=").*(?=" from=)') | sed 's|\n+|,|g' )  <"$i"_result1.xml   >"$i"_result1.xmlTMP    
      

      # Extract the corresponding transitions from the trace file of UPPAAL
      ((sed 's|<transition|\n|g' | grep -o -P '(?<= edges=").*(?="/>)') | sed 's|\n+|,|g' )   <"$i"_result1.xml  >"$i"_result1.xmlTMP1    


     # Summarise the trace into list
     runhaskell traceUPPAAL.hs "$i"_result1.xmlTMP  "$i"_result1.xmlTMP1   $(dirname "$i"_result1.xmlTMP1) 
done
      
# Subtract the accepted traces with forbidden initials from the valid FDR traces       
for i in GenFiles/* ; do
    if [ -s $i/monitor/traceForMonitor* ] 
    then    
         # invokes haskell program for subtracting valid traces from invalid traces
         echo "subtracting valid traces"
         runhaskell subtractInvalidTraces.hs    "$i"/ForbiddeInits/traceRes  "$i"/FDR/traceResFDR  "$i"/ForbiddeInits/
    fi
done


# Copy all the traces that has added forbidden initials into one file traceSetComparison
for i in GenFiles/* ; do
    if [ -s $i/monitor/traceForMonitor* ] 
    then
        echo  $'\n\n'$(basename $i) "traces with an added forbidden initial :" $'\n'{ >> $i/traceSetComparison
        cat   $i/ForbiddeInits/traceWithForbiddenInit  >> $i/traceSetComparison
        echo "}" >> $i/traceSetComparison
    fi
done



# Copy the result of the verification of traces with the added forbidden intials
for i in GenFiles/* ; do
    if [ -s $i/monitor/traceForMonitor* ] 
    then
        echo $'\n\n'$(basename $i)" accepted traces with an added forbidden initial :" $'\n'{ >> $i/traceSetComparison
        cat $i/ForbiddeInits/traceRes  >> $i/traceSetComparison
        echo "}" >> $i/traceSetComparison
    fi
done


