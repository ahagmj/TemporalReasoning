-- TODO 
-- This program is a Haskell implementation of the translation function, which translates tock-CSP into TA.
-- Structure of the file. An overview of the contents is as follows.
-- 1. Definition of the translation function 
-- 2. A function env that generates a TA for the model of environment
-- 3. A function syncTA that generates a TA for controlling synchronisations
-- 4. A function genFiles that generates relevant files and folders for verification using both FDR and UPPAAL
-- 5. Definition of the other functions used in the program

-- Todo: adding prompt for error warning, like tock can not be part of the hiding events

---------------------------------------------------------------------------
module TF where

import System.Directory
import Data.List
-- Imports the definition of the abstract syntax tock-CSP suitable for timed section of FDR.
import CSP
-- Imports the definition of the abstract syntax of TA suitable for UPPAAL.
import TA


---------------------------------------------------------------------------------
-- 1. Definition 
-- Function for translating tock-CSP into TA. 
-- The function takes a named tock-CSP process and an integer value for trace length

transform :: NamedProc  -> TA
transform    npr        =  TA   []      decls       temps     ins     (System ins)  []       n
       -- CSPprocess traceSize = TA   Imports Declaration Template InstTag  System       Queries  TraceSize
     where
       NamedProc pid pr = npr
       decls = [( VariableDecl  (Type Meta TypeChan)   -- Declares channels
               ([(VariableID   "tick"                   [])                                 ] ++  --declare event tick
                [(VariableID   "iitick"                 [])                                 ] ++  --intermediary tick
               -- Todo, remove iitick? for improvement, to consider replacing tick with iitick
                [(VariableID   "itau"                   [])                                 ] ++  -- declare itau 
               [( VariableID  ("startID" ++   id      ) []) | id <- (sids ++ uniq (pid:(processIDs pr)))] ++ --plus PIDs
               [(VariableID   ("finishID"++  (show id)) []) | id <- [0..15]] ++    -- ?? how many finishIDs
               [(VariableID   (ev  ++ "_intrpt")        []) | (ID ev) <- (uniq $ events pr) ] ++
               [(VariableID   (id)                      []) | (ID id) <- (removeSync $ removeExch $ uniq $ events pr),
               id /= "tock", id /= "tick" ] )),
--               \\ [Tock, Tick]) ] )),      -- declare  all events in the process   
                                          -- avoid multi-declaration with removing external choice, sync and tock event
               -- Declare broadcast channels
               ( VariableDecl (Type Broadcast TypeChan) ([(VariableID "tock"                   [])    ] ++ 
               [(VariableID   (id ++ "_exch") []) | (ID id) <- (uniq (events pr) ++ [(ID "itau")])    ] ++ 
               [(VariableID    id             []) | (ID id) <- (uniq (onlySync (events pr)))          ] ++ 
--               [(VariableID   (show id) []) | id <- (uniq (onlyExch (events pr) ++ onlySync (events pr) ) )] ++ 
--               [(VariableID   (show ev ++ "_intrpt") []) | ev <- uniq (events pr) ] ++               
               [(VariableID   (show ev ++ "___sync") []) | ev <- syncEvents ] )),               
               (VariableDecl  (Type Meta TypeClock) [(VariableID     "ck"      [])]),   -- Declare clock ck
               -- Declares Boolean variables
               (VariableDecl  (Type Meta TypeBool) ([(VariableIDInit ("ep_" ++ d) [] (Initialiser (Val 0)))| 
                                                    d <- sids, not (null d)]  ++   -- )),     -- path identity
                                                    [(VariableIDInit ("ep_FID0")  [] (Initialiser (Val 0)))] ++
                                                    [(VariableIDInit ("ep_" ++ e ++ "_sync") [] (Initialiser (Val 0)))|
                                                    (ID e) <- (uniq (events pr)) ] ++  -- path ID with sync
                                                    [(VariableIDInit (e ++ "_intrpt_guard") [] (Initialiser (Val 0)))|
                                                    (ID e) <- (uniq (events pr)) ]  -- interrupt guard
                                                    )), 
               -- Declares integer variables
               (VariableDecl (Type Meta TypeInt  ) 
                            ([(VariableIDInit ("d"++d)  [] (Initialiser (Val 0)))| d <- sids, not (null d)] ++ 
                             -- declare the delay var d                                    
                            [(VariableIDInit "ready_c"  [] (Initialiser (Val 0))),  --for synch
                            (VariableIDInit "gIntrpt"   [] (Initialiser (Val 0))),  --for synch 
                            (VariableIDInit "guard_c"   [] (Initialiser (Val 1))),
                            (VariableIDInit "start"     [] (Initialiser (Val 0))),
                            (VariableIDInit "dp"        [] (Initialiser (Val 0))),    -- depth decl
                            (VariableIDInit "tdeadline" [] (Initialiser (Val 0)))] ++  -- for timed deadline
                            [(VariableID ("g_" ++ tag)  [] )  | (e, tag) <- uniq syncMap] ++
--                            [(VariableID ("g_" ++ show e ++ tag) [])  | (e, tag) <- uniq syncMap] ++
                            [(VariableID (id   ++ "_exch_ready" ) []) | (ID id ) <- ((uniq (events pr)) ++ [(ID "itau")]) ]
                            )
                            )]
                             -- To update with computing the number of synch processes
                                                
       (pTA, syncs, syncMap) = (transTA pr pid "0" 0 0 [] [] [] [] [] [] [])
       temps = (env pid (removeSync $ removeExch $ uniq $ events pr)):pTA ++ [syncTA syncs syncMap]
             -- TA for env, translation and syncronisation.
             -- Concatenates TA for a model of the environment using the function env, 
             -- with the TA for the collection of TAs that defines a process, and the TA synchronisation controller. 
             -- (env (uniq $ events)) to ensure that the TA for env does not have multiple trans with the same event 

       -- Instantiates the templates of the TA
       ins  = [(Instantiation ('p':id) t []) | (t, id) <- (zip temps (map (\(Template id _ _ _ _ _ _) -> id) temps))]

       -- Extracts the ids from the template ids (size is 8), for generating and declaring the startIDs.
       sids = (map snd (map (splitAt 8) (map (\(Template id _ _ _ _ _ _) -> id) (tail temps))))
        
       syncEvents = uniq  [id | (id, tag) <- uniq syncMap] 

----------------------------------------------------------------------------------

type SyncEvent      =  Event
type FireEvent      =  Event
type HidingEvent    =  Event
type ExChoiceEvent  =  Event
type Interrupt      =  Event
type InitInterrupt  =  Event
type SyncInfo       = (Event, Int)
type Rename         = (Event, Event)
type SyncMap        = (Event, String)
type Named          =  String


-- Definition of function transTA ----------------------------------------------------------------------------
transTA :: CSPproc -> Named ->  String -> Int -> Int -> [SyncEvent] -> [SyncMap] -> [HidingEvent]-> [Rename]-> [ExChoiceEvent] ->  [Interrupt] -> [InitInterrupt] -> ([Template], [Event], [SyncMap])   -- [SyncInfo])


-- STOP translation  -------------------------------------------------------------------------
transTA   STOP       namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =
           ([(Template  ("taSTOP__" ++ bid ++ show sid)  []  [] locs [] (Init loc1)  trans)], [], [])
          -- Template    Name Parameters DeclTag  [Location]  [Branchpoint]  Init [Transition]
                   where 
                                 --   = Location ID Name Label LocType
                        loc1  = Location "id1" "s1" EmptyLabel None
                        loc2  = Location "id2" "s2" EmptyLabel None
                        locs  = [loc1, loc2]

                         --   = Transition Source Target [Label] [Nail]
                        tran1 = Transition loc1 loc2 [lab1] []
                        tran2 = Transition loc2 loc2 [lab2] []
                        trans =  [tran1, tran2]

--                                lab1 = Sync (VariableID "startSTOP" [])  Ques
                        lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                                else Sync (VariableID ("startID" ++ namedP) [])  Ques
                                
--                                lab1  = Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                        lab2  = Sync (VariableID "tock"                  [])  Ques     
                                

-- STOP translation --------------------------------------------------------------------------
transTA   SKIP       namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =
                       transTA (Wait 0) namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt


-- Zero Delay translation -------------------------------------------------------------------
transTA (Wait 0)     namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =
                    ([(Template  ("taWait_n" ++ bid ++ show sid)  []  [] locs [] (Init loc1)  trans)], [], [])
                 --Template =  Template  Name Parameters DeclTag  [Location]  [Branchpoint]  Init [Transition]
                   where 
                        loc1  =  Location "id1" "s1" EmptyLabel None
                        loc2  =  Location "id2" "s2" EmptyLabel None
                        loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc
                        -- data Location = Location ID Name Label LocType
                        locs  =  [loc1, loc2, loc3]   -- , loc4]

                        tran1 =  Transition loc1 loc2 [lab1]    []
                        tran2 =  Transition loc2 loc2 [lab2]    []   
            
                        tran3 =  Transition loc2 loc3 [lab3]    []
                        tran4 =  Transition loc3 loc1 [lab4]    []                                       
                        -- data Transition = Transition Source Target [Label] [Nail]
                        trans =  [tran1, tran3, tran4] ++ transIntrpt


--                                lab1  =   Sync   ( VariableID       ("startID"  ++ bid ++ show sid)  [])  Ques
                        lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                                else Sync (VariableID ("startID" ++ namedP) [])  Ques

                        lab2  =   Sync   (VariableID         "tock"                  [])  Ques     -- lable tock
                        lab3  =   Sync   (VariableID         "tick"                  [])  Excl  
--                        lab3  =   Sync   (VariableID        "iitick"                 [])  Excl  
                        lab4  =   Sync   (VariableID       ("finishID" ++ show fid)  [])  Excl 
                                  
            -- Add transitions for possible interrupt
                        transIntrpt = 
                          if null intrpt 
                          then []
                          else [(Transition loc2 loc1 [(Sync (VariableID ((show l ) ++ "_intrpt") []) Ques)] [])|l <- intrpt]
--                           else [(Transition  loc2 loc1 [(Sync (VariableID  (show l)  [])  Ques)] [] )| l <- intrpt ]
     

-- Delay translation -------------------------------------------------------------------------
transTA (Wait n) namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =
            transTA (Prefix Tock (Wait (n - 1))) namedP bid sid fid syncs syncMap hides rename chs intrpt initIntrpt


-- Prefix translation ------------------------------------------------------------------------------
transTA (Prefix     e1 p)  namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =  -- []
        (([(Template  ("taPrefix" ++ bid ++ show sid) [] [] locs [] (Init loc1)  trans)] ++ ta1), sync1, syncMapUpdate)
--        (([(Template  ("taPrefix" ++ bid ++ show sid) [] [] locs [] (Init loc1)  trans)] ++ ta1), sync1, syncMap1) 
          where 
            -- check renaming, and replace the name if it is part of the renaming
--            e = if null ces then e1
--                else snd (head ces)

            e   | null ces        = e1           --  if the event is not rename
                | elem e1   hides = ID "itau"    --  if the event is part of the hide
--                 | (not $ null ces) && (elem e1 hides) = 
                | otherwise       = snd (head ces)
           
            -- Find its new rename event from the parameter rename  
            ces  = [(es, nn) | (es, nn) <- rename, es == e1]
--            (es', nn') = head ces

            -- if the choice event is rename replaced it with new name
            chs'   =  if  ( null crs ) then chs
                      else  (chs \\ [es']) ++ [nn']
                        
            -- rename event that is part of external choice
            crs  = [(es, nn) | (es, nn) <- rename, ch <- chs, ch == es]
                        
            (es', nn') = head crs

            -----------------------------------------------------------  
--   data Location =  Location  ID    Name  Label      LocType                    
            loc1   =  Location "id1"  "s1"  EmptyLabel None
            loc2   =  Location "id2"  "s2"  EmptyLabel None
            loc2c  =  Location "id2"  "s2"  EmptyLabel CommittedLoc            
            loc3   =  Location "id3"  "s3"  EmptyLabel None
            loc3c  =  Location "id3"  "s3"  EmptyLabel CommittedLoc
            loc4   =  Location "id4"  "s4"  EmptyLabel None
            loc4c  =  Location "id4"  "s4"  EmptyLabel CommittedLoc
            loc5   =  Location "id5"  "s5"  EmptyLabel CommittedLoc
            loc6   =  Location "id6"  "s6"  EmptyLabel CommittedLoc

-- todo: to combine locs and locs1
            locs  | elem e hides && null chs         = [loc1, loc2, loc5]
--                  |(elem e hides) && (elem e [es | (es, n) <- rename]) 
--                                                     = [loc1, loc2, loc5]
--                  |(elem e [e | (e, n) <- rename])   = [loc1, loc2, loc5]
                  | otherwise                        = locs1                  

-- New locs for the possible pattern of sync, choice and interrupt  111,110, 101, 100, 011,010, 001, 000
            locs1 | ((not $ elem e syncs) && (      null chs) && (      null initIntrpt )) = [loc1, loc2, loc5]
                  | ((not $ elem e syncs) && (      null chs) && (not $ null initIntrpt )) = [loc1, loc2, loc3c, loc5]
                  | ((not $ elem e syncs) && (not $ null chs) && (      null initIntrpt )) = [loc1, loc2, loc3c, loc5]
                  | ((not $ elem e syncs) && (not $ null chs) && (not $ null initIntrpt )) = 
                                                                                      [loc1, loc2, loc3c, loc4c, loc5]
                  | ((      elem e syncs) && (      null chs) && (      null initIntrpt )) = [loc1, loc2, loc3,  loc5]
                  | ((      elem e syncs) && (      null chs) && (not $ null initIntrpt )) = 
                                                                                      [loc1, loc2, loc3,  loc4c, loc5]
                  | ((      elem e syncs) && (not $ null chs) && (      null initIntrpt )) = 
                                                                                      [loc1, loc2, loc3,  loc4,  loc5]
                  | ((      elem e syncs) && (not $ null chs) && (not $ null initIntrpt )) = 
                                                                                [loc1, loc2, loc3,  loc4,  loc5, loc6] 
--                   | otherwise                                  = [loc1, loc2, loc3,  loc4, loc5]


----------------------------------------------------------------------------------------
--  todo: to consider combining trans and trans1
            -- Construting transitions
            trans  | elem e hides && null chs          = [t12, t25h,  t51] ++ addTran
--                   |(elem e hides) && (elem e [es | (es, n) <- rename])   
--                                                       = [t12, t25h,  t51] ++ addTran   
--                   |(elem e [es | (es, n) <- rename])    = [t12, t25r,  t51] ++ addTran
                   | otherwise                         = trans1                  

            
            trans1 | ((not $ elem e syncs) && (      null chs) && (      null initIntrpt )) = 
                                                                        [t12, t25,  t51]      ++ addTran ++ transIntrpt
                   | ((not $ elem e syncs) && (      null chs) && (not $ null initIntrpt )) = 
                                -- if process can interrupt and also be interrupted, 
                                -- then it can only be interrupted after initiating its interrupt
                               if not $ null intrpt then  [t12G, t23ci, t3c5, t51]  ++ addTran -- ++transIntrpt
--                             if not $ null intrpt then  [t12G, t23ci, t23cgi, t3c5, t51]  ++ addTran -- ++transIntrpt
                               else                 [t12, t23ci, t23cgi, t3c5, t51]  ++ addTran ++ transIntrpt
                   | ((not $ elem e syncs) && (not $ null chs) && (      null initIntrpt )) = 
                                                             [t12, t23c, t3c5, t51] ++ t23e   ++ addTran ++ transIntrpt
                   | ((not $ elem e syncs) && (not $ null chs) && (not $ null initIntrpt )) = 
                                                    [t12G, t23c, t3c4ci, t3c4cgi, t4c5e, t51] ++ addTran ++ transIntrpt
                   | ((      elem e syncs) && (      null chs) && (      null initIntrpt )) = 
                                                    [t12, t23, t35, t51 ]                 ++ addTran ++ transIntrpt
                   | ((      elem e syncs) && (      null chs) && (not $ null initIntrpt )) = 
                                                    [t12G, t23, t34c, t4c5i, t4c5gi, t51] ++ addTran ++ transIntrpt
                   | ((      elem e syncs) && (not $ null chs) && (      null initIntrpt )) = 
                                                          [t12, t23ech,  t34, t45, t51]   ++ addTran ++ transIntrpt
--                    | ((      elem e syncs) && (not $ null chs) && (      null intrpt )) = [t12, tran2,  t51,  t34, t45]   ++ addTran
                   | ((      elem e syncs) && (not $ null chs) && (not $ null initIntrpt )) = 
                                                    [t12G, t23, t34c, t4c6, t65, t65gi, t51 ] ++ addTran ++ transIntrpt
--                   | otherwise                                  = [loc1, loc2, loc3,  loc4, loc5]

            -- Additional transitions
            addTran | ((not $ elem e syncs) && (null chs))       = [t22]  -- ++ transIntrpt
                    | ((elem e syncs)       && (null chs))       = [t22]  -- ++ transIntrpt
                    | ((not $ elem e syncs) && (not $ null chs)) = [t22] ++ t21 -- ++ transIntrpt
                    | otherwise                                  = [t22, t33, t44] ++ t21 -- ++ transIntrpt

            
            -- Transitions for possible interrupt
            -- todo: to improve by removing the if condition? 
            transIntrpt = 
               if null intrpt 
               then []
               else 
                [(Transition  loc2 loc1 [(Sync (VariableID ((show l ) ++ "_intrpt")  [])  Ques)] [] )| l <- intrpt ]

            
            
            --------------------------------------------------------------------------------------------
            startEvent =  if null namedP then "startID" ++ bid ++ show sid
                          else "startID" ++ namedP

--            t23ci  = Transition  loc2   loc3c  (l23ci ++ uIntrpt)  []     -- to remove all uIntrpt
            t23ci  = Transition  loc2   loc3c   l23ci      []     -- to remove all uIntrpt
            t23cgi = Transition  loc2   loc3c   altIntrpt  []
            l23ci  = [(Sync (VariableID   ((show e) ++ "_intrpt")  [])  Excl), 
                      (Update  [(AssgExp  (ExpID ((show e) ++ "_intrpt_guard")) ASSIGNMENT TrueExp )])]
            --  And alternative transition in case another event has initites the interrupt.
            --  Guarded with conjunctions of all the possible interrupts, 
            --  such that any of the interrupt can enable the alternative transition
            altIntrpt = [(Guard (ExpID (intercalate " || "  [l ++"_intrpt_guard"| (ID l) <- initIntrpt])))]
           
            -- reset the guards in case of recursive process
            resetG = [Update  [(AssgExp  (ExpID (l ++ "_intrpt_guard")) ASSIGNMENT FalseExp)| (ID l) <- initIntrpt ]]
            
            t3c5   = Transition  loc3c  loc5   lab4e  []
                           
            t3c4ci  = Transition  loc3c  loc4c   l23ci      []  -- enable other concurent transitions
            t3c4cgi = Transition  loc3c  loc4c   altIntrpt  []  -- guarded interrupt, incase of a concurent TA
--            t3c4ci = Transition  loc3c  loc4c  (l23ci ++ uIntrpt)  []  -- enable other conccurent transitions
--            t3c4cgi = Transition  loc3c  loc4c  gIntrpt  []            -- guarded interrupt, incase of a concurent TA that interrupt the other TA before this one
            t4c5   = Transition  loc4c  loc5   (lab2i ++ lab2d)  []    -- block external choice
            t4c5e  = Transition  loc4c  loc5   lab4e  []    -- For event
            
            t34c   = Transition  loc3   loc4c  lab4   []
            t3c4c  = Transition  loc3c  loc4c  lab4e  []
                        
            t4c5i  = Transition  loc4c  loc5   l23ci     []
            t4c5gi = Transition  loc4c  loc5   altIntrpt []            
            
            t4c6   = Transition  loc4c  loc6   (lab2i ++ lab2d)  []

            t65    = Transition  loc6   loc5   l23ci      []
            t65gi  = Transition  loc6   loc5   altIntrpt  []                        
--            t65    = Transition  loc6   loc5   (l23ci ++ uIntrpt)  []
--            t65gi  = Transition  loc6   loc5   gIntrpt  []            
            
            
            

            t12    = Transition  loc1  loc2    lab1  []
            t12G   = Transition  loc1  loc2   (lab1 ++ resetG)  []     -- reset guard
            
            t23    = Transition  loc2  loc3    lab2i []
            t2c3   = Transition  loc2c loc3    lab2i []            
            t23c   = Transition  loc2  loc3c  (lab2i ++ lab2d) []    
            t23ech = Transition  loc2  loc3    (lab2i ++ lab2d)  []
                        
            t25    = Transition  loc2  loc5    lab2i [] 

            -- with hiding
            t25h   = Transition  loc2 loc5  ([(Sync (VariableID   "itau"       []) Excl)] ) [] -- for hiding
--            t25h   = Transition  loc2 loc5  ([(Sync (VariableID   "itau"       []) Excl)] ++ labpath) [] -- for hiding
            
            -- for renaming
            t25r   = Transition  loc2 loc5  ([(Sync (VariableID  (show new_e) []) Excl)] ++ labpath)  [] --for renaming
            new_e  =  head [newname | (oldname, newname) <- rename, oldname == e]
               
            t51    = Transition  loc5 loc1   [lab3] []       -- start next TA, from loc3, loc4 or loc 5    

            t33    = Transition loc3 loc3 [labTock]     []   -- tock transition    
            t44    = Transition loc4 loc4 [labTock]     []   -- tock transition   

            t35    = Transition loc3  loc5 lab4         []
--            t3c5   = Transition loc3c loc5 (lab2i ++ lab2d)        []           -- For external choice        

            t22    = Transition   loc2 loc2 [labTock]   []   -- tock transition      
                       
            t21    = [(Transition loc2 loc1 [ (Sync   (VariableID ((show ch) ++ "_exch")  []) Ques)] [])|ch <- chs']
            t23e   = [(Transition loc2 loc3 [ (Guard  (ExpID      ((show ch) ++ "_exch_ready")) )]   [])|ch <- chs']
                                           
            t34    = Transition loc3 loc4 lab6  []

            t45    = Transition loc4 loc5 lab4  []
            
            

            lab1  = [(Sync (VariableID startEvent []) Ques )  ] 

            lab2i | (elem e syncs) && (null chs')  =    -- check the sync guard
                        [(Guard  (BinaryExp  (ExpID ("g_" ++ (eTag e syncMap_ "")))  Equal     (Val 0))), 
                        (Update  [(AssgExp   (ExpID ("g_" ++ (eTag e syncMap_ ""))) AddAssg    (Val 1))])]
                  | (not $ null chs') = if (elem e hides) then [(Sync (VariableID  "itau_exch"  []) Excl)]
                                        else [(Sync (VariableID  ((show e ) ++ "_exch")  []) Excl)]  -- ++ labpath   
--                  | (elem e chs') = [(Sync (VariableID  ((show e ) ++ "_exch")  []) Excl)] ++ labpath   
                  | otherwise    =  lab4e   -- Fire normal event or tock
--                  | otherwise    = [(Sync (VariableID   (show e)  []) Excl)] ++ labpath   -- Fire normal event with!
            
            
            labpath =  [(Update  [(AssgExp (ExpID "dp") AddAssg (Val 1)), -- Attach counter dp
                        (AssgExp  (ExpID ("ep_" ++ bid ++ show sid)) ASSIGNMENT TrueExp )])]
                                          -- Attaching path variable to this tranistion

            lab3  = Sync (VariableID ("startID" ++ bid ++ show (sid+1))  [])  Excl 

            lab4  = [(Sync (VariableID   ((show e) ++ "___sync")  [])  Ques)] 


            lab4e | e == Tock    = [(Sync (VariableID   (show e)  []) Ques)] ++ labpath  -- Sync on tocks
                  | elem e hides = [(Sync (VariableID   ("itau")  []) Excl)] -- ++ labpath  -- Fire itau for hiding event
                  | otherwise    = [(Sync (VariableID   (show e)  []) Excl)] ++ labpath  -- Fire normal event

             
{-            lab4e = if e == Tock 
                    then [(Sync (VariableID   (show e)  []) Ques)] ++ labpath  -- Sync on tocks
                    else [(Sync (VariableID   (show e)  []) Excl)] ++ labpath  -- Fire normal event for external choice
-}            
            lab6  = [(Guard  (BinaryExp  (ExpID ("g_" ++ (eTag e syncMap_ ""))) Equal     (Val 0))), 
                    (Update  [(AssgExp   (ExpID ("g_" ++ (eTag e syncMap_ ""))) AddAssg   (Val 1))])]
                    
                    
            lab2d = [(Update [(AssgExp  (ExpID ((show ch) ++ "_exch_ready")) AddAssg   (Val 1)) | ch <- chs'])]        

            gIntrpt = [(Guard  (BinaryExp  (ExpID "gIntrpt" ) Equal     (Val 1)))]
            
            uIntrpt = [(Update  [(AssgExp   (ExpID "gIntrpt" ) AddAssg   (Val 1))] )]
                      
            labTock  = Sync (VariableID  "tock"                             [])  Ques
            
            syncMap_ = if elem e syncs 
                       then [(e, (show e) ++ bid ++ show sid )]  -- ++ syncMap_ 
                       else [] -- syncMap_

            syncMapUpdate = syncMap_ ++ syncMap1

            -- finally recursive call for subsequent translation.
            (ta1, sync1, syncMap1) = transTA p []  bid (sid+1) fid syncs syncMap hides rename [] intrpt []


-- Internal choices translation ---------------------------------------------------------------------
transTA (IntChoice  p1 p2)  namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =  -- []
                   ([(Template  ("taIntCho" ++ bid ++ show sid)  []  [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2,
                   sync1 ++ sync2, syncMap1 ++ syncMap2)
                   where 
                        loc1  =  Location "id1" "s1" EmptyLabel None
                        loc2  =  Location "id2" "s2" EmptyLabel CommittedLoc
                        loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc
                        loc4  =  Location "id4" "s4" EmptyLabel CommittedLoc

                        locs  =  [loc1, loc2, loc3, loc4]

                        tran1 =  Transition loc1 loc2 [lab1]  []
                        tran2 =  Transition loc2 loc3 []      []
                        tran3 =  Transition loc2 loc4 []      []
                        tran4 =  Transition loc3 loc1 [lab4]  []                                       
                        tran5 =  Transition loc4 loc1 [lab5]  []                                       

                        trans =  [tran1, tran2, tran3, tran4, tran5]

--                                lab1  =  Sync (VariableID ("startID" ++  bid ++         show sid)      [])  Ques
                        lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                                else Sync (VariableID ("startID" ++ namedP) [])  Ques

                        lab4  =  Sync (VariableID ("startID" ++ (bid ++ "0") ++ show (sid+1))  [])  Excl 
                        lab5  =  Sync (VariableID ("startID" ++ (bid ++ "1") ++ show (sid+2))  [])  Excl
                        
                        (ta1, sync1, syncMap1) = 
                            transTA p1 [] (bid ++ "0") (sid+1) fid syncs syncMap hides rename chs intrpt initIntrpt
                        (ta2, sync2, syncMap2) = 
                            transTA p2 [] (bid ++ "1") (sid+2) fid syncs syncMap hides rename chs intrpt initIntrpt
                      

-- External choice translation -----------------------------------------------------------------------
transTA (ExtChoice  p1 p2)   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =  
              ([(Template ("taExtCho" ++ bid ++ show sid) [] [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2,
              sync1 ++ sync2, syncMap1 ++ syncMap2)                  
              where 
              loc1  =  Location "id1" "s1" EmptyLabel None
              loc2  =  Location "id2" "s2" EmptyLabel CommittedLoc
              loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc

              locs  = [loc1, loc2, loc3]

              tran1 =  Transition loc1 loc2 [lab1]  []
              tran2 =  Transition loc2 loc3 [lab2]  []
              tran3 =  Transition loc3 loc1 [lab3]  []
                
              trans = [tran1, tran2, tran3]

              lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                      else Sync (VariableID ("startID" ++ namedP) [])  Ques

              lab2  =   Sync (VariableID ("startID" ++ (bid ++ "0") ++ show (sid+1))  [])  Excl 
              lab3  =   Sync (VariableID ("startID" ++ (bid ++ "1") ++ show (sid+2))  [])  Excl 

              (ta1, sync1, syncMap1) = 
                  (transTA p1 [] (bid ++ "0") (sid+1) fid syncs syncMap hides rename (chs ++ (initials p2))) intrpt initIntrpt
              (ta2, sync2, syncMap2) = 
                  (transTA p2 [] (bid ++ "1") (sid+2) fid syncs syncMap hides rename (chs ++ (initials p1))) intrpt initIntrpt


-- Translation of sequential composition ------------------------------------------------------------
transTA (Seq        p1 p2)    namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt = 
                ([(Template  ("taSequen" ++ bid ++ show  sid )  []  [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2,
                 sync1 ++ sync2, syncMap1 ++ syncMap2)
--                (fst taP1 ++ fst taP2), (snd taP1 ++ snd taP2))
                
            where 
            loc1  =  Location "id1" "s1" EmptyLabel None
            loc2  =  Location "id2" "s2" EmptyLabel CommittedLoc
            loc3  =  Location "id3" "s3" EmptyLabel None
            loc4  =  Location "id4" "s4" EmptyLabel CommittedLoc
            -- data Location = Location ID Name Label LocType
            locs  =  [loc1, loc2, loc3, loc4]

            tran1 =  Transition loc1 loc2 [lab1]  []
            tran2 =  Transition loc2 loc3 [lab2]  []
            tran3 =  Transition loc3 loc4 [lab3]  []
            tran4 =  Transition loc4 loc1 [lab4]  []                                
            -- data Transition = Transition Source Target [Label] [Nail]
            
            trans =  [tran1, tran2, tran3, tran4]

--            lab1  =  Sync (VariableID ("startID"  ++  bid ++         show  sid   )  []) Ques
            lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                    else Sync (VariableID ("startID" ++ namedP) [])  Ques

            lab2  =  Sync (VariableID ("startID"  ++ (bid ++ "0") ++ show (sid+1))  []) Excl 
            lab3  =  Sync (VariableID ("finishID" ++                 show (fid+1))  []) Ques 
--                                lab3  =  Sync (VariableID ("finishID" ++  bid ++         show (fid+1))  []) Ques 
            lab4  =  Sync (VariableID ("startID"  ++ (bid ++ "1") ++ show (sid+2))  []) Excl 

            (ta1, sync1, syncMap1)  = 
                    transTA p1 [] (bid ++ "0")  (sid+1) (fid+1) syncs syncMap hides rename chs intrpt initIntrpt
            (ta2, sync2, syncMap2)  = 
                    transTA p2 [] (bid ++ "1")  (sid+2)  fid    syncs syncMap hides rename chs intrpt []



-- Interleave translation in the form of generallised parallel with empty sync ---------------------
transTA (Interleave p1 p2) namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =  
            transTA (GenPar p1 p2 []) namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt 
                                -- As generalised parallel with empty synch events
                                
-- Generallised parallel translation ---------------------------------------------------------------
--transTA (GenPar     p1 p2 es) bid sid fid syncs syncMap hides chs =  -- []
transTA (GenPar  p1 p2 es) namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =  
                    ([(Template  ("taGenPar" ++ bid ++ show sid)  []  [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2,
                    es ++ sync1 ++ sync2, syncMap1 ++ syncMap2)
                    where
                        syncs'   = es ++ syncs

                        (ta1, sync1, syncMap1) = 
                          transTA p1 [] (bid ++ "0") (sid+1) (fid+1) syncs' syncMap hides rename chs intrpt initIntrpt
                        (ta2, sync2, syncMap2) = 
                          transTA p2 [] (bid ++ "1") (sid+2) (fid+2) syncs' syncMap hides rename chs intrpt initIntrpt
                        
-------------------------                    
                        loc1   =  Location "id1"  "s1"  EmptyLabel None
                        loc2   =  Location "id2"  "s2"  EmptyLabel CommittedLoc
                        loc2a  =  Location "id2a" "s2a" EmptyLabel CommittedLoc
                        loc3   =  Location "id3"  "s3"  EmptyLabel CommittedLoc
                        loc4   =  Location "id4"  "s4"  EmptyLabel None
                        loc5   =  Location "id5"  "s5"  EmptyLabel None
                        loc6   =  Location "id6"  "s6"  EmptyLabel None
                        loc7   =  Location "id7"  "s7"  EmptyLabel CommittedLoc
                        
                        locs   = [loc1, loc2, loc2a, loc3, loc4, loc5, loc6, loc7]
                        
                     -- data Transition = Transition Source Target [Label] [Nail]
                        tran1  =  Transition loc1  loc2  [lab1]  []
                        tran1a =  Transition loc2  loc2a [lab3]  [] 
                        tran1b =  Transition loc2a loc4  [lab2]  []
                        tran2  =  Transition loc2  loc3  [lab2]  []
                        tran3  =  Transition loc3  loc4  [lab3]  []
                        tran4  =  Transition loc4  loc5  [lab4]  []                                       
                        tran5  =  Transition loc4  loc6  [lab5]  [] 
                        tran6  =  Transition loc5  loc7  [lab5]  [] 
                        tran7  =  Transition loc6  loc7  [lab4]  [] 
                        tran8  =  Transition loc7  loc1  [lab6]  []                                 
                        
                        trans  =  [tran1, tran1a, tran1b, tran2, tran3, tran4, tran5, tran6, tran7, tran8]

--                        lab1  =   Sync (VariableID ("startID"  ++  bid ++         show   sid    )  [])  Ques
                        lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                                else Sync (VariableID ("startID" ++ namedP) [])  Ques

                        lab2  =  Sync (VariableID ("startID"  ++ (bid ++ "0") ++ show  (sid+1 ))  [])  Excl 
                        lab3  =  Sync (VariableID ("startID"  ++ (bid ++ "1") ++ show  (sid+2 ))  [])  Excl 
                        lab4  =  Sync (VariableID ("finishID"                 ++ show  (fid+1 ))  [])  Ques
                        lab5  =  Sync (VariableID ("finishID"                 ++ show  (fid+2 ))  [])  Ques
                        lab6  =  Sync (VariableID ("finishID"                 ++ show   fid    )  [])  Excl 


-- Named process translation -------------------------------------------------------------------------
transTA (ProcID      pid )   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt = -- ([],[],[])
                      ([(Template  ("taNamedP" ++ bid ++ show  sid )  []  [] locs [] (Init loc1) trans )], [], [])
                      where 
                        loc1  =  Location "id1" "s1" EmptyLabel None
                        loc2  =  Location "id2" "s2" EmptyLabel None

                        locs  =  [loc1, loc2]

                        tran1 =  Transition loc1 loc2 [lab1]  []
                        tran2 =  Transition loc2 loc1 [lab2]  []
                        -- data Transition = Transition Source Target [Label] [Nail]

                        trans =  [tran1, tran2]                        

--                        lab1  =  Sync (VariableID ("startID"  ++  bid ++ show  sid )  []) Ques
                        lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                                else Sync (VariableID ("startID" ++ namedP) [])  Ques

                        lab2  =  Sync (VariableID ("startID"    ++  pid              )  []) Excl 

{-                        lab4  =  Sync (VariableID ("startID"  ++ (bid ++ "1") ++ show (sid+2))  []) Excl 

                        (ta1, sync1, syncMap1)  = 
                           transTA p1 [] (bid ++ "0")  (sid+1) (fid+1) syncs syncMap hides rename chs intrpt initIntrpt
                        (ta2, sync2, syncMap2)  = 
                           transTA p2 [] (bid ++ "1")  (sid+2)  fid    syncs syncMap hides rename chs intrpt initIntrpt
-}

-- Interrupt translation ------------------------------------------------------------------------------
transTA (Interrupt  p1 p2 )   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =  -- ([],[],[])
-- transTA (ExtChoice  p1 p2)   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =  
          ([(Template ("taIntrpt" ++ bid ++ show sid) [] [] locs [] (Init loc1) trans )] ++ ta1 ++ ta2,
          sync1 ++ sync2, syncMap1 ++ syncMap2)                  
--                    fst res1 ++ fst res2), (snd res1 ++ snd res2))
                -- (chs ++ (initials p1) to propagate external choice in case of multiple external choice
          where 
          loc1  =  Location "id1"  "s1"  EmptyLabel None
          loc2  =  Location "id2"  "s2"  EmptyLabel CommittedLoc  -- None
          loc3  =  Location "id3"  "s3"  EmptyLabel CommittedLoc

          locs  = [loc1, loc2, loc3]

          t12   =  Transition loc1  loc2  [lab1]  []
          t23   =  Transition loc2  loc3  [lab2]  [] 
          t31   =  Transition loc3  loc1  [lab3]  []
            
          trans =  [t12, t23, t31]

          lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                  else Sync (VariableID ("startID" ++ namedP) [])  Ques

          lab2  =   Sync (VariableID ("startID" ++ (bid ++ "0") ++ show (sid+1))  [])  Excl 
          lab3  =   Sync (VariableID ("startID" ++ (bid ++ "1") ++ show (sid+2))  [])  Excl 

          (ta1, sync1, syncMap1) = 
           (transTA p1 [] (bid ++ "0") (sid+1) fid syncs syncMap hides rename chs (intrpt ++ (initials p2)) initIntrpt)
          (ta2, sync2, syncMap2) = 
           (transTA p2 [] (bid ++ "1") (sid+2) fid syncs syncMap hides rename chs  intrpt  (initIntrpt ++ (initials p2)))

-- Timeout translation ---------------------------------------
-- Timeout, according to Joel thesis [1], the timeout is translated into external choices as follows
-- (P [d> Q) = P [] (Wait(d);timeout -> Q) \{timeout}
-- [1] Ouaknine, Joel. Discrete analysis of continuous behaviour in real-time concurrent systems. 
-- Diss. University of Oxford, 2000.

transTA (Timeout    p1 p2 d)   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt = -- ([],[],[])
    transTA (IntChoice  p1 (Seq (Wait d) p2 ))  namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt



-- Hiding translation ----------------------------------------
transTA (Hiding     p  es )   namedP     bid sid fid syncs syncMap hides         rename chs intrpt initIntrpt = 
              transTA ( p )   namedP     bid sid fid syncs syncMap (es ++ hides) rename chs intrpt initIntrpt
              -- The remaining translation is under the translation of prefix 

---- Renaming translation ------------------------------------
transTA (Rename     p  pes)    namedP    bid sid fid syncs syncMap hides  rename         chs  intrpt initIntrpt = 
              transTA ( p )    namedP    bid sid fid syncs syncMap hides (rename ++ pes) chs  intrpt initIntrpt 
              -- The remaining translation is under the translation of prefix              

-- Pending operators--------------------------------------------------------
-- transTA (Interrupt  p1 p2 )   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt = ([],[],[])
-- transTA (Timeout    p1 p2 )   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt = ([],[],[])
-- transTA (Hiding     p  es )   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt = ([],[],[])
-- transTA (Rename     p  eps)   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt = ([],[],[])   
-- transTA (Proc       np    )   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt = ([],[],[])
transTA (Parproc    id n )   namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt = ([],[],[])
----------------------------------------------------------------------------------------------------------

-- Event deadline translation -------------------------------------------------------------------
transTA (EDeadline e n)    namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =
                    ([(Template  ("taDeadln" ++ bid ++ show sid)  []  [] locs [] (Init loc1)  trans)], [], [])
                 --Template =  Template  Name Parameters DeclTag  [Location]  [Branchpoint]  Init [Transition]
                   where 
                        loc1  =  Location "id1" "s1" EmptyLabel None
                        loc2  =  Location "id2" "s2" EmptyLabel None
                        loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc
                        -- data Location = Location ID Name Label LocType
                        locs  =  [loc1, loc2, loc3]   -- , loc4]

                        tran1 =  Transition loc1 loc2 ([lab1] ++ t_reset)               []
                                     -- add reset time for deadline
                        tran2 =  Transition loc2 loc2 ([lab2] ++ dlguard  ++ dlupdate)   []               
--                        tran2 =  Transition loc2 loc2 ([lab2] ++ dlguard  ++ dlupdate ++ labpath)   []               
                        tran3 =  Transition loc2 loc3 ([lab3] ++ dl_reset ++ labpath)               []
                        tran4 =  Transition loc3 loc1  [lab4]    []                                       
                        -- data Transition = Transition Source Target [Label] [Nail]
                        trans =  [tran1, tran2, tran3, tran4] ++ transIntrpt

--                                lab1  =   Sync   ( VariableID       ("startID"  ++ bid ++ show sid)  [])  Ques
                        lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                                else Sync (VariableID ("startID" ++ namedP) [])  Ques
                        -- reset deadline time        
                        t_reset   =  [(Update  [(AssgExp   (ExpID "tdeadline" ) ASSIGNMENT   (Val 0))] )]    

                        lab2      =   Sync   (VariableID         "tock"                  [])  Ques     -- lable tock
                        lab3      =   Sync   (VariableID         (show e)                [])  Excl  

                        dlguard   = [(Guard   (BinaryExp  (ExpID "tdeadline" ) Lth        (Val n)))]
                        dlupdate  = [(Update  [(AssgExp   (ExpID "tdeadline" ) AddAssg    (Val 1))] )]
                        
                        dl_reset  = [(Update  [(AssgExp   (ExpID "tdeadline" ) ASSIGNMENT (Val 1))] )]
                        
                        -- Add guard for deadlines
                        lab4    =   Sync   (VariableID       ("finishID" ++ show fid)  [])  Excl 
                                                
                        labpath =  [(Update  [(AssgExp (ExpID "dp") AddAssg (Val 1)), -- Attach counter dp
                                    (AssgExp  (ExpID ("ep_" ++ bid ++ show sid)) ASSIGNMENT TrueExp )])]
                                          -- Attaching path variable to this tranistion
                                  
                        -- Add transitions for possible interrupt
                        transIntrpt = 
                          if null intrpt 
                          then []
                          else [(Transition loc2 loc1 [(Sync (VariableID ((show l ) ++ "_intrpt") []) Ques)] [])|l <- intrpt]
--                           else [(Transition  loc2 loc1 [(Sync (VariableID  (show l)  [])  Ques)] [] )| l <- intrpt ]
     

-- Immediate termination SKIP0 -----------------------------------------------------------------------
transTA   SKIP0     namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =
                    ([(Template  ("taSKIP0_" ++ bid ++ show sid)  []  [] locs [] (Init loc1)  trans)], [], [])
                 --Template =  Template  Name Parameters DeclTag  [Location]  [Branchpoint]  Init [Transition]
                   where 
                        loc1  =  Location "id1" "s1" EmptyLabel None
                        loc2  =  Location "id2" "s2" EmptyLabel None
                        loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc
                        -- data Location = Location ID Name Label LocType
                        locs  =  [loc1, loc2, loc3]   -- , loc4]

                        tran1 =  Transition loc1 loc2 [lab1]    []
--                        tran2 =  Transition loc2 loc2 [lab2]    []   
            
                        tran3 =  Transition loc2 loc3 [lab3]    []
                        tran4 =  Transition loc3 loc1 [lab4]    []                                       
                        -- data Transition = Transition Source Target [Label] [Nail]
                        trans =  [tran1, tran3, tran4] ++ transIntrpt


--                                lab1  =   Sync   ( VariableID       ("startID"  ++ bid ++ show sid)  [])  Ques
                        lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                                else Sync (VariableID ("startID" ++ namedP) [])  Ques

--                        lab2  =   Sync   (VariableID         "tock"                  [])  Ques     -- lable tock
                        lab3  =   Sync   (VariableID         "tick"                  [])  Excl  
--                        lab3  =   Sync   (VariableID        "iitick"                 [])  Excl  
                        lab4  =   Sync   (VariableID       ("finishID" ++ show fid)  [])  Excl 
                                  
            -- Add transitions for possible interrupt
                        transIntrpt = 
                          if null intrpt 
                          then []
                          else [(Transition loc2 loc1 [(Sync (VariableID ((show l ) ++ "_intrpt") []) Ques)] [])|l <- intrpt]
--                           else [(Transition  loc2 loc1 [(Sync (VariableID  (show l)  [])  Ques)] [] )| l <- intrpt ]
     
--------------------------------------------------------------------------                      







-- Countdown translation -------------------------------------------------------------------
transTA (Countdown n)    namedP     bid sid fid syncs syncMap hides rename chs intrpt initIntrpt =
                    ([(Template  ("taCndown" ++ bid ++ show sid)  []  [] locs [] (Init loc1)  trans)], [], [])
                 --Template =  Template  Name Parameters DeclTag  [Location]  [Branchpoint]  Init [Transition]
                   where 
                        loc1  =  Location "id1" "s1" EmptyLabel None
                        loc2  =  Location "id2" "s2" EmptyLabel None
--                        loc3  =  Location "id3" "s3" EmptyLabel CommittedLoc
                        -- data Location = Location ID Name Label LocType
                        locs  =  [loc1, loc2]   -- , loc4]

                        tran1 =  Transition loc1 loc2 ([lab1] ++ t_reset)                []
                                     -- add reset time for deadline
                        tran2 =  Transition loc2 loc2 ([lab2] ++ dlguard  ++ dlupdate)   []               
--                        tran2 =  Transition loc2 loc2 ([lab2] ++ dlguard  ++ dlupdate ++ labpath)   []               
--                        tran3 =  Transition loc2 loc3 ([lab3] ++ dl_reset ++ labpath)               []
                        tran4 =  Transition loc2 loc1  ([lab4] ++ dlguard2 ++ t_reset)   []           
                        -- data Transition = Transition Source Target [Label] [Nail]
                        trans =  [tran1, tran2, tran4]  -- ++ transIntrpt

--                                lab1  =   Sync   ( VariableID       ("startID"  ++ bid ++ show sid)  [])  Ques
                        lab1  = if null namedP then Sync (VariableID ("startID" ++ bid ++ show sid) [])  Ques
                                else Sync (VariableID ("startID" ++ namedP) [])  Ques
                        -- reset deadline time        
                        t_reset   =  [(Update  [(AssgExp   (ExpID "tdeadline" ) ASSIGNMENT   (Val 0))] )]    

                        lab2      =   Sync   (VariableID         "tock"                  [])  Ques     -- lable tock
--                        lab3      =   Sync   (VariableID         (show e)                [])  Excl  

                        dlguard   = [(Guard   (BinaryExp  (ExpID "tdeadline" ) Lth        (Val n)))]
                        dlupdate  = [(Update [(AssgExp    (ExpID "tdeadline" ) AddAssg    (Val 1))] )]
                        dlguard2  = [(Guard   (BinaryExp  (ExpID "tdeadline" ) Equal      (Val n)))]
                        
--                        dl_reset  = [(Update  [(AssgExp   (ExpID "tdeadline" ) ASSIGNMENT (Val 1))] )]
                        
                        -- Add guard for deadlines
                        lab4    =   Sync   (VariableID       ("finishID" ++ show fid)  [])  Excl 
                                                
--                        labpath =  [(Update  [(AssgExp (ExpID "dp") AddAssg (Val 1)), -- Attach counter dp
--                                    (AssgExp  (ExpID ("ep_" ++ bid ++ show sid)) ASSIGNMENT TrueExp )])]
                                          -- Attaching path variable to this tranistion
                                  
                        -- Add transitions for possible interrupt
--                        transIntrpt = 
--                          if null intrpt 
--                          then []
--                          else [(Transition loc2 loc1 [(Sync (VariableID ((show l ) ++ "_intrpt") []) Ques)] [])|l <- intrpt]
--                           else [(Transition  loc2 loc1 [(Sync (VariableID  (show l)  [])  Ques)] [] )| l <- intrpt ]


                   


--------------------------------------------------------------
-- env :: [Event] -> ID -> Template
-- env es "startID00"            -- for proc
-- ene es show namedProc         -- for named proc

-- 3. Function for generating the TA of the environment. The function takes name of first process and all other events
env :: String -> [Event] -> Template
--         = Template Name  Parameters [Declaration]  [Location]  [Branchpoint]  Init       [Transition]
env pid es = Template "Env" []         []             [loc]       []             (Init loc) trans
               where loc   = Location "taEnv" "taEnv" EmptyLabel None
                     trans = [(Transition loc loc [(Sync   (VariableID id          [])  Ques)] [])|(ID id) <- es] ++ 
                             [Transition  loc loc [(Sync   (VariableID "startID00"        [])  Excl),
                                                   (Guard  (BinaryExp  (ExpID "start")  Equal      (Val 0))),
                                                   (Update [(AssgExp   (ExpID "start")  ASSIGNMENT (Val 1))])]  [], 
                             Transition  loc loc [(Sync   (VariableID ("startID" ++ pid)        [])  Excl),
                                                   (Guard  (BinaryExp  (ExpID "start")  Equal      (Val 0))),
                                                   (Update [(AssgExp   (ExpID "start")  ASSIGNMENT (Val 1))])]  [], 
                             Transition   loc loc [(Sync   (VariableID "finishID0" [])  Ques),
                                                   (Update  [(AssgExp (ExpID "dp") AddAssg (Val 1)), -- counter dp
                                                   (AssgExp  (ExpID ("ep_FID0" )) ASSIGNMENT TrueExp )])  ] [],
--                                                   (Update  [(AssgExp (ExpID "dp") AddAssg (Val 1))]) ] [],
                             Transition   loc loc [(Sync   (VariableID "tick"      [])  Ques)] [],  
                             Transition   loc loc [(Sync   (VariableID "iitick"    [])  Ques)] [],  
                             Transition   loc loc [(Sync   (VariableID "itau"      [])  Ques)] [],  
                             Transition   loc loc [(Sync   (VariableID "tock"      [])  Excl),                 
                                                   (Guard  $ BinaryExp  (ExpID "ck") Lte         (Val 1)), 
                                                   (Update [AssgExp     (ExpID "ck") ASSIGNMENT  (Val 0)] )]   []]


-- Examples -------------------------------------
env1 = env  "p1" (events (Prefix (ID "e1") SKIP))
env2 = env  "p2" (events p2)


----------------------------------------------------------------------------------
-- 4. Generates TA for controlling the synchronisations point
-- The definition of "trans" below, adds a prefix "v_" to an event name to form a variable name that each TA increments to register its readiness to sync.
syncTA :: [Event] -> [SyncMap] -> Template
syncTA    events      syncMaps  = Template "SyncTA" [] [] (loc:locs) [] (Init loc) tran0s 
                    where 
                    loc    = Location "SyncPoint" "SyncPoint" EmptyLabel None                   
                    locs   = [(Location ("s"++ show e) ("s"++ show e) EmptyLabel CommittedLoc) |
                             e <- uniq events]
                    tran0s = transGen loc (uniq events)  syncMaps  events
                    


--  Generates transitions for the sync controller
--          States      syncEvents  syncMap       ListOfsyncEvents   -> Transitions
transGen :: Location -> [Event] ->  [SyncMap]  -> [Event]  -> [Transition]
transGen    l0          []            _            _       =  []
transGen    l0          (e:es)       syncMaps      syncs   =  [(Transition l0 l [(Sync   (VariableID (show e) []) Excl),
                                 (Guard  (ExpID ( (addExpr [("g_" ++ tag) | (e1, tag) <- syncMaps, e == e1 ]) 
--                                 (Guard  (ExpID ( (addExpr [("g_" ++ show e) ++ tag | (e1, tag) <- syncMaps, e == e1 ]) 
                                 ++ "== " ++ show ((length [e1 | e1 <- syncs, e == e1 ]) + 1) ) )), 
--                                 (Update ([ AssgExp    (ExpID  ("g_" ++ show e ++ tag)) ASSIGNMENT  (Val 0)  |
                                 (Update ([ AssgExp    (ExpID  ("g_" ++ tag)) ASSIGNMENT  (Val 0)  |
                                 (e1, tag) <- syncMaps, e == e1 ]   ++ 
                                 labpath            ) ) ] [])]   ++
                                 [Transition l l0 [(Sync (VariableID ((show e) ++ "___sync") []) Excl)] [] ] ++ 
                                 (transGen  l0  es  syncMaps syncs)  
                                 where
                                 l        = (Location ("s"++ show e) ("s"++ show e) EmptyLabel CommittedLoc)
                                 labpath  = [(AssgExp (ExpID  "dp" ) AddAssg (Val 1)), -- Attach counter dp
                                            (AssgExp  (ExpID ("ep_" ++ show e ++"_sync")) ASSIGNMENT TrueExp )]


-- addExpr list of and expression as string, omit the AST of and expressions
addExpr :: [String]    -> String
addExpr    []          =  ""
addExpr    [e]         =  e
addExpr    (e:es)      =  e ++ " + " ++ addExpr es

-- andExpr list of and expression as string, omit the AST of and expressions
andExpr :: [String]    -> String
andExpr              []     = ""
andExpr              [e]    = e
andExpr              (e:es) = e ++ " and " ++ andExpr es

---------------------------------------------------------------------------------------------
--5. Function for generating files and folders for both FDR and UPPAAL systems
genFiles :: Int     -> [NamedProc] -> IO [()]
genFiles    _          []           = sequence []
genFiles    traceSize  ps           = 
            sequence ((cspFolders ++ cspFiles ++ uppaalFolders ++ uppaalFiles) ++ [syntax, events] ++ 
            [monitorFolder, monitorTA])  
                where 
                (NamedProc pName pr) = head ps
                
                -- Write the concrete syntax of the process into a file for output together with the result
                syntax  = writeFile  ("GenFiles/" ++ pName ++ "/FDR/syntax")  
                                     (ishowLinesSt [show p | p <- ps] )
                
                -- Create directory for each size 1..5
                cspFolders    = map (\x -> (createDirectoryIfMissing True ("GenFiles/" ++ 
                                pName ++ "/FDR/" ++ pName ++ "_s" ++ show x)))  [1..traceSize]
                
                -- Write a CSP file for each size
                cspFiles      = map (\x -> (writeFile ("GenFiles/" ++ pName ++ "/FDR/" ++ pName ++ "_s" ++ 
                                show x ++ "/" ++   pName ++ "_s" ++ show x ++ ".csp") 
                                (cspfile ps x))) [1..traceSize]

                -- Write the alphabets of the process into a text file event
                events        = writeFile  ("GenFiles/" ++ pName ++ "/FDR/events")  (ishowLines (eventsNPND (head ps)))
                
                -- Create directory for Uppaal files
                uppaalFolders = map (\x -> (createDirectoryIfMissing True ("GenFiles/" ++ 
                                pName ++ "/Uppaal/" ++ pName ++ "_s" ++ show x)))  [1..traceSize]

                -- Transform the processs into TA for UPPAAL
                uppaalFiles   = map (\x -> (writeFile ("GenFiles/" ++ pName ++ "/Uppaal/" ++ pName ++ "_s" ++
                                show x ++ "/" ++ pName ++ "_s" ++ show x ++ ".xml") 
                                (fileHeader ++ show (transform (head ps) x) ))) [1..traceSize]

                monitorFolder = createDirectoryIfMissing True ("GenFiles/" ++ pName ++ "/monitor" )

                -- Transform the processs into TA for UPPAAL
                monitorTA    =  writeFile ("GenFiles/" ++ pName ++ "/monitor/" ++ pName ++ "_TA" ++ ".xml") 
                                (fileHeader ++ show (transform (head ps) 0 ))



--6. Other functions  -----------------------------------------------------------

-- Remove external choice events
removeExch    :: [Event] -> [Event]
removeExch es =  [x | x <- es, (take 5 (reverse (show x)))  /= (reverse "_exch")]

-- Remove sync events
removeSync    :: [Event] -> [Event]
removeSync es =  [x | x <- es, (take 5 (reverse (show x)))  /= (reverse "_sync")]

-- Only external choice events
onlyExch    :: [Event] -> [Event]
onlyExch es =  [x | x <- es, (take 5 (reverse (show x)))  == (reverse "_exch")]

-- Only synch events
onlySync    :: [Event] -> [Event]
onlySync es =  [x | x <- es, (take 5 (reverse (show x)))  == (reverse "_sync")]

--count :: Event -> [Event] -> Int
count :: Eq a => a -> [a] -> Int
count e es = length [ne | ne <- es, ne == e]

-- Get the first element of a list of pairs
ifstdom xs = [f | (f,s) <- xs ]

-- Return a tag of an event e from sync with a string s in between
-- eTag :: Event -> [(Event, String)] -> Maybe String 
eTag :: Event -> [(Event, String)] -> String -> String 
eTag    e        []                s         =  []
-- eTag    e        (x:tags)          s         =  if e == fst x then (show e ++ s ++ snd x)
eTag    e        (x:tags)          s         =  if e == fst x then (s ++ snd x)
                                                else eTag e tags s




