-- Test examples for combining the operators of tock-CSP.

import TF
import CSP
import TA
import Data.List
import System.Environment   
import System.Directory


main  = do -- print "start"

                   createDirectoryIfMissing True "PerformanceForAllExamples/GenFiles"  

                   let traceSize = 1
           
                   -- All the provided processes
                   genFiles traceSize [np0_1]
                   
                   genFiles traceSize [np0_2]

                   genFiles traceSize [np0_3]
                             
                   genFiles traceSize [np0_4]

                   genFiles traceSize [np0_5]
                   
                   genFiles traceSize [np0_6]

                   genFiles traceSize [np0_7]
                   
                   genFiles traceSize [np0_8]
                   
                   genFiles traceSize [np0_9]
                   
                   genFiles traceSize [np1_0]  
                   
                   genFiles traceSize [np1_1]
                   
                   genFiles traceSize [np1_2]

                   genFiles traceSize [np1_3]
                   
                   genFiles traceSize [np1_4]

                   genFiles traceSize [np1_5]
                   
                   genFiles traceSize [np1_6]    

                   genFiles traceSize [np1_7]    

                   genFiles traceSize [np2_2]

                   genFiles traceSize [np2_3]
                   
                   genFiles traceSize [np2_4]

                   genFiles traceSize [np2_5]
                   
                   genFiles traceSize [np2_6]
                   
                   genFiles traceSize [np2_7]

                   genFiles traceSize [np3_2]

                   genFiles traceSize [np3_3]
                   
                   genFiles traceSize [np3_4]

                   genFiles traceSize [np3_5]
                   
                   genFiles traceSize [np3_6]    

                   genFiles traceSize [np3_7]
                   
                   genFiles traceSize [np4_2]

                   genFiles traceSize [np4_3]
                   
                   genFiles traceSize [np4_4]

                   genFiles traceSize [np4_5]
                   
                   genFiles traceSize [np4_6]
                   
                   genFiles traceSize [np4_7] 

                   genFiles traceSize [np5_2]

                   genFiles traceSize [np5_3]
                   
                   genFiles traceSize [np5_4]   

                   genFiles traceSize [np5_5]
                   
                   genFiles traceSize [np5_6]
                   
                   genFiles traceSize [np5_7]                                         

                   genFiles traceSize [nsp6_1]
                   
                   genFiles traceSize [nsp6_2]
                   
                   genFiles traceSize [nsp6_3]  
                   
                   genFiles traceSize [nsp6_4]  
                   
                   genFiles traceSize [nsp6_5]  
                   
                   genFiles traceSize [nsp6_6]  

                   genFiles traceSize [nsp6_7]
                   
                   genFiles traceSize [nsp6_8]
                   
                   genFiles traceSize [nsp6_9]   
                   
                   genFiles traceSize [nsp6_10]  
                   
                   genFiles traceSize [nsp6_11] -- , p6_11]  
                   
                   genFiles traceSize [nsp6_12] -- , p6_11]  
                   
                   genFiles traceSize [nsp6_13] -- , p6_11]
                   
                   genFiles traceSize [nsp6_14]
                   
                   genFiles traceSize [nsp6_15]  
          
                   -- Sequential composition
                   genFiles traceSize [np7_2]

                   genFiles traceSize [np7_3]
                   
                   genFiles traceSize [np7_4]

                   genFiles traceSize [np7_5]
                   
                   genFiles traceSize [np7_6]
                   
                   genFiles traceSize [np7_7]                   

                   -- Interrupt                   
                   genFiles traceSize [np8_2]

                   genFiles traceSize [np8_3]
                   
                   genFiles traceSize [np8_4]

                   genFiles traceSize [np8_5]
                   
                   genFiles traceSize [np8_6]
                   
                   genFiles traceSize [np8_7]    
                   
                   -- Timeout ---------------
                   genFiles traceSize [np9_1]
                   
                   genFiles traceSize [np9_2]
                   
                   genFiles traceSize [np9_3]
                   
                   genFiles traceSize [np9_4] 
                   
                   genFiles traceSize [np9_5]                  
                
                   genFiles traceSize [np9_6]
                   
                   genFiles traceSize [np9_7]
                   
                   genFiles traceSize [np9_8]
                   -- to do, reverse, operators with timeout      
                                     
                   
                   -- Hiding -----------------
                   genFiles traceSize [np10_1]
                   
                   genFiles traceSize [np10_2]
                   
                   genFiles traceSize [np10_3]
                   
                   genFiles traceSize [np10_4] 
                   
                   genFiles traceSize [np10_5]                  
                
                   genFiles traceSize [np10_6]
                   
                   genFiles traceSize [np10_7] 
                   
                   -- Hiding multiple events
                   genFiles traceSize [np10_1m]
                   
                   genFiles traceSize [np10_2m]
                   
                   genFiles traceSize [np10_3m]
                   
                   genFiles traceSize [np10_4m] 
                   
                   genFiles traceSize [np10_5m]                  
                
                   genFiles traceSize [np10_6m]
                   
                   genFiles traceSize [np10_7m]                

                   -- Hiding empty events
                   genFiles traceSize [np10_1e]
                   
                   genFiles traceSize [np10_2e]
                   
                   genFiles traceSize [np10_3e]
                   
                   genFiles traceSize [np10_4e] 
                   
                   genFiles traceSize [np10_5e]                  
                
                   genFiles traceSize [np10_6e]
                   
                   genFiles traceSize [np10_7e]  
                   
                   -- Hiding single event in one side of binary operators
                   genFiles traceSize [np10_2s]
                   
                   genFiles traceSize [np10_3s]
                   
                   genFiles traceSize [np10_4s] 
                   
                   genFiles traceSize [np10_5s]                  
                
                   genFiles traceSize [np10_6s]
                   
                   genFiles traceSize [np10_7s]                

                   -- Hiding multiple events in one side of binary operators
                   genFiles traceSize [np10_2ms]
                   
                   genFiles traceSize [np10_3ms]
                   
                   genFiles traceSize [np10_4ms] 
                   
                   genFiles traceSize [np10_5ms]                  
                
                   genFiles traceSize [np10_6ms]
                   
                   genFiles traceSize [np10_7ms]                

                   -- Hiding empty events in one side of binary operators
                   genFiles traceSize [np10_2es]
                   
                   genFiles traceSize [np10_3es]
                   
                   genFiles traceSize [np10_4es] 
                   
                   genFiles traceSize [np10_5es]                  
                
                   genFiles traceSize [np10_6es]
                   
                   genFiles traceSize [np10_7es]                
                                                    
                                  
                   -- Renaming
                   genFiles traceSize [np11_1]
                   
                   genFiles traceSize [np11_2]
                   
                   genFiles traceSize [np11_3]
                   
                   genFiles traceSize [np11_4] 
                   
                   genFiles traceSize [np11_5]                  
                
                   genFiles traceSize [np11_6]
                   
                   genFiles traceSize [np11_7]

                   -- Other special cases
                   genFiles traceSize [np12_1]
                   
                   genFiles traceSize [np12_2]                                      
                   
                                 
                
                
{-                  -- Interrupt 
                   genFiles traceSize [np1_7]
                   
                   genFiles traceSize [np2_7]
                   
                   genFiles traceSize [np3_7]
                   
                   genFiles traceSize [np4_7] 
                   
                   genFiles traceSize [np5_7]                  
                
                   genFiles traceSize [np7_7]
-}                   
                   --------------------------
                                      
                                    
                              

         
-------------------------------------------------------------------
-- Choice of a process         
           
pick  traceSize  pNo   | (pNo == "01") = genFiles traceSize [np0_1]
                       
                       | (pNo == "02") = genFiles traceSize [np0_2]
                       
                       | (pNo == "03") = genFiles traceSize [np0_3]
                       
                       | (pNo == "04") = genFiles traceSize [np0_4]

                       | (pNo == "05") = genFiles traceSize [np0_5]
                       
                       | (pNo == "06") = genFiles traceSize [np0_6]

                       | (pNo == "07") = genFiles traceSize [np0_7]
                       
                       | (pNo == "08") = genFiles traceSize [np0_8]
                       
                       | (pNo == "09") = genFiles traceSize [np0_9]
                       
                       | (pNo == "0A") = genFiles traceSize [np1_0]
                       
                       | (pNo == "0B") = genFiles traceSize [np8_1]  
                       
                       | (pNo == "0C") = genFiles traceSize [nptdl] 
                       
                       | (pNo == "11") = genFiles traceSize [np1_1]
                       
                       | (pNo == "12") = genFiles traceSize [np1_2]

                       | (pNo == "13") = genFiles traceSize [np1_3]
                       
                       | (pNo == "14") = genFiles traceSize [np1_4]

                       | (pNo == "15") = genFiles traceSize [np1_5]
                       
                       | (pNo == "16") = genFiles traceSize [np1_6]    
                       
                       | (pNo == "17") = genFiles traceSize [np1_7]                           

                       | (pNo == "22") = genFiles traceSize [np2_2]

                       | (pNo == "23") = genFiles traceSize [np2_3]
                       
                       | (pNo == "24") = genFiles traceSize [np2_4]

                       | (pNo == "25") = genFiles traceSize [np2_5]
                       
                       | (pNo == "26") = genFiles traceSize [np2_6]
                       
                       | (pNo == "27") = genFiles traceSize [np2_7]                       

                       | (pNo == "32") = genFiles traceSize [np3_2]

                       | (pNo == "33") = genFiles traceSize [np3_3]
                       
                       | (pNo == "34") = genFiles traceSize [np3_4]

                       | (pNo == "35") = genFiles traceSize [np3_5]
                       
                       | (pNo == "36") = genFiles traceSize [np3_6]    

                       | (pNo == "37") = genFiles traceSize [np3_7]
                       
                       | (pNo == "42") = genFiles traceSize [np4_2]

                       | (pNo == "43") = genFiles traceSize [np4_3]
                       
                       | (pNo == "44") = genFiles traceSize [np4_4]

                       | (pNo == "45") = genFiles traceSize [np4_5]
                       
                       | (pNo == "46") = genFiles traceSize [np4_6]
                       
                       | (pNo == "47") = genFiles traceSize [np4_7]                           

                       | (pNo == "52") = genFiles traceSize [np5_2]

                       | (pNo == "53") = genFiles traceSize [np5_3]
                       
                       | (pNo == "54") = genFiles traceSize [np5_4]   

                       | (pNo == "55") = genFiles traceSize [np5_5]
                       
                       | (pNo == "56") = genFiles traceSize [np5_6] 

                       | (pNo == "57") = genFiles traceSize [np5_7]                                            

                       | (pNo == "61") = genFiles traceSize [nsp6_1]
                       
                       | (pNo == "62") = genFiles traceSize [nsp6_2]
                       
                       | (pNo == "63") = genFiles traceSize [nsp6_3]  
                       
                       | (pNo == "64") = genFiles traceSize [nsp6_4]  
                       
                       | (pNo == "65") = genFiles traceSize [nsp6_5]  
                       
                       | (pNo == "66") = genFiles traceSize [nsp6_6]  

                       | (pNo == "67") = genFiles traceSize [nsp6_7]
                       
                       | (pNo == "68") = genFiles traceSize [nsp6_8]
                       
                       | (pNo == "69") = genFiles traceSize [nsp6_9]   
                       
                       | (pNo == "610") = genFiles traceSize [nsp6_10]  
                       
                       | (pNo == "611") = genFiles traceSize [nsp6_11]  -- , p6_11]  
                       
                       | (pNo == "612") = genFiles traceSize [nsp6_12]  -- , p6_11]  
                       
                       | (pNo == "613") = genFiles traceSize [nsp6_13]  -- , p6_11]
                       
                       | (pNo == "614") = genFiles traceSize [nsp6_14]
                       
                       | (pNo == "615") = genFiles traceSize [nsp6_15]  
                       
                       -- Sequential composition
                       | (pNo == "72") = genFiles traceSize [np7_2]

                       | (pNo == "73") = genFiles traceSize [np7_3]
                       
                       | (pNo == "74") = genFiles traceSize [np7_4]   

                       | (pNo == "75") = genFiles traceSize [np7_5]
                       
                       | (pNo == "76") = genFiles traceSize [np7_6] 
                       
                       | (pNo == "77") = genFiles traceSize [np7_7]                                            

                       -- Interrupt
                       | (pNo == "81") = genFiles traceSize [np8_1]  
                       
                       | (pNo == "82") = genFiles traceSize [np8_2]

                       | (pNo == "83") = genFiles traceSize [np8_3]
                       
                       | (pNo == "84") = genFiles traceSize [np8_4]   

                       | (pNo == "85") = genFiles traceSize [np8_5]
                       
                       | (pNo == "86") = genFiles traceSize [np8_6]    
                       
                       | (pNo == "87") = genFiles traceSize [np8_7]   
                       
                       -- Timeout
                       | (pNo == "91") = genFiles traceSize [np9_1]  
                       
                       | (pNo == "92") = genFiles traceSize [np9_2]

                       | (pNo == "93") = genFiles traceSize [np9_3]
                       
                       | (pNo == "94") = genFiles traceSize [np9_4]   

                       | (pNo == "95") = genFiles traceSize [np9_5]
                       
                       | (pNo == "96") = genFiles traceSize [np9_6]    
                       
                       | (pNo == "97") = genFiles traceSize [np9_7]
                       
                       | (pNo == "98") = genFiles traceSize [np9_8]                                               
                                                             
                       -- Hiding
                       | (pNo == "101") = genFiles traceSize [np10_1]  
                       
                       | (pNo == "102") = genFiles traceSize [np10_2]

                       | (pNo == "103") = genFiles traceSize [np10_3]
                       
                       | (pNo == "104") = genFiles traceSize [np10_4]   

                       | (pNo == "105") = genFiles traceSize [np10_5]
                       
                       | (pNo == "106") = genFiles traceSize [np10_6]    
                       
                       | (pNo == "107") = genFiles traceSize [np10_7]

                       -- Hiding multiple events
                       | (pNo == "101m") = genFiles traceSize [np10_1m]  
                       
                       | (pNo == "102m") = genFiles traceSize [np10_2m]

                       | (pNo == "103m") = genFiles traceSize [np10_3m]
                       
                       | (pNo == "104m") = genFiles traceSize [np10_4m]   

                       | (pNo == "105m") = genFiles traceSize [np10_5m]
                       
                       | (pNo == "106m") = genFiles traceSize [np10_6m]    
                       
                       | (pNo == "107m") = genFiles traceSize [np10_7m]

                       -- Hiding empty events
                       | (pNo == "101e") = genFiles traceSize [np10_1e]  
                       
                       | (pNo == "102e") = genFiles traceSize [np10_2e]

                       | (pNo == "103e") = genFiles traceSize [np10_3e]
                       
                       | (pNo == "104e") = genFiles traceSize [np10_4e]   

                       | (pNo == "105e") = genFiles traceSize [np10_5e]
                       
                       | (pNo == "106e") = genFiles traceSize [np10_6e]    
                       
                       | (pNo == "107e") = genFiles traceSize [np10_7e]
                                              
                       -- Hiding in one side of binary operator
                       -- Hiding
                       | (pNo == "102s") = genFiles traceSize [np10_2s]

                       | (pNo == "103s") = genFiles traceSize [np10_3s]
                       
                       | (pNo == "104s") = genFiles traceSize [np10_4s]   

                       | (pNo == "105s") = genFiles traceSize [np10_5s]
                       
                       | (pNo == "106s") = genFiles traceSize [np10_6s]    
                       
                       | (pNo == "107s") = genFiles traceSize [np10_7s]

                       -- Hiding multiple events
                       | (pNo == "102ms") = genFiles traceSize [np10_2ms]

                       | (pNo == "103ms") = genFiles traceSize [np10_3ms]
                       
                       | (pNo == "104ms") = genFiles traceSize [np10_4ms]   

                       | (pNo == "105ms") = genFiles traceSize [np10_5ms]
                       
                       | (pNo == "106ms") = genFiles traceSize [np10_6ms]    
                       
                       | (pNo == "107ms") = genFiles traceSize [np10_7ms]

                       -- Hiding empty events
                       | (pNo == "102es") = genFiles traceSize [np10_2es]

                       | (pNo == "103es") = genFiles traceSize [np10_3es]
                       
                       | (pNo == "104es") = genFiles traceSize [np10_4es]   

                       | (pNo == "105es") = genFiles traceSize [np10_5es]
                       
                       | (pNo == "106es") = genFiles traceSize [np10_6es]    
                       
                       | (pNo == "107es") = genFiles traceSize [np10_7es]
                       
                       
                       -- Rename
                       | (pNo == "111") = genFiles traceSize [np11_1]  
                       
                       | (pNo == "112") = genFiles traceSize [np11_2]

                       | (pNo == "113") = genFiles traceSize [np11_3]
                       
                       | (pNo == "114") = genFiles traceSize [np11_4]   

                       | (pNo == "115") = genFiles traceSize [np11_5]
                       
                       | (pNo == "116") = genFiles traceSize [np11_6]    
                       
                       | (pNo == "117") = genFiles traceSize [np11_7]
                       
                       --other special cases
                       | (pNo == "121") = genFiles traceSize [np12_1]                       
                       
                       | (pNo == "122") = genFiles traceSize [np12_2] 
                       
                       -- RoboChart models
                       | (pNo == "123") = genFiles traceSize [np12_3]
                                         
                       | (pNo == "124") = genFiles traceSize [np12_4]
                       
                       | (pNo == "125") = genFiles traceSize [npa_1]    -- SKIP0, strict termination                
                       
                       | (pNo == "126") = genFiles traceSize [npa_2]    -- countdown, the trict time budget  
                       
                       -- out of range
                       | otherwise      = sequence [(putStrLn "Invalid process number, please check again.")] 
                        
                       

           

--------------------------------------------------------------------------------------------           
-- ~~~~~~~~~~~~~~~~~~~~~~~ Definition of the processes  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -- 

--- Basic examples -------------------------------------------------------------------------

-- Example 0.1 
np0_1 = NamedProc "p0_1" STOP


-- Example 0.2 
np0_2 = NamedProc "p0_2" SKIP


-- Example 0.3 
np0_3 = NamedProc "p0_3" (Wait 2)
-- np0_3 = NamedProc "p0_3" (Wait 3)


-- Example 0.4 
np0_4 = NamedProc "p0_4" (Prefix (ID "e1") SKIP)


-- Example 0.5 
np0_5 = NamedProc "p0_5" (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))


 -- Example 0.6 
np0_6 = NamedProc "p0_6" (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))


-- Example 0.7 
np0_7 = NamedProc "p0_7" (Seq (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP))


-- Example 0.8 
np0_8 = NamedProc "p0_8" (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP))


-- Example 0.9 
np0_9 = NamedProc "p0_9" (GenPar (Prefix (ID "e1") SKIP) (Prefix (ID "e1") SKIP) [ID "e1"])


-- Example 1.0 : P = e -> P
np1_0 = NamedProc "p1_0" (Prefix (ID "e1") (ProcID "p1_0"))
--np1_0 = NamedProc "p1_0" (Prefix (ID "e1") SKIP)

-- RoboChart constructs
-- Example event deadline
nptdl = NamedProc "ptdl" (EDeadline (ID "e1") 3)

-- Example 12 
npa_1 = NamedProc "pa_1" SKIP0

-- Example 13
npa_2 = NamedProc "pa_2" (Countdown 3)



--01--  Prefix ----------------------------------------------------------------------------------------
-- Example 1.1 : Prefix with prefix 
np1_1 = NamedProc "p1_1" (Prefix (ID "e1") (Prefix (ID "e2") SKIP))


-- Example 1.2: Prefix with Internal choice
np1_2 = NamedProc "p1_2" (Prefix (ID "e1") (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 1.3: Prefix with External choice
np1_3 = NamedProc "p1_3" (Prefix (ID "e1") (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 1.4: Prefix with Interleave 
np1_4 = NamedProc "p1_4" (Prefix (ID "e1") (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 1.5: Prefix with Generallise parallel 
np1_5 = NamedProc "p1_5" (Prefix (ID "e1") (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 1.6: Prefix with Sequential composition 
np1_6 = NamedProc "p1_6" (Prefix (ID "e1") (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 1.7: Prefix with Interrupt composition 
np1_7 = NamedProc "p1_7" (Prefix (ID "e1") (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) )


--02 Internal choice -------------------------------------------------------------------------  

-- Example 2.1 : Internal choice with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p

-- Example 2.2: Internal choice with Internal choice
np2_2  = NamedProc "p2_2" (IntChoice (Prefix (ID "e2") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 2.3: Internal choice with External choice
np2_3 = NamedProc "p2_3" (IntChoice (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 2.4: Internal choice with Interleave 
np2_4 = NamedProc "p2_4" 
        (IntChoice (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))

-- Example 2.5: Internal choice with Generallise parallel 
np2_5 = NamedProc "p2_5" 
        (IntChoice (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 2.6: Internal choice with Sequential composition 
np2_6 = NamedProc "p2_6" 
        (IntChoice (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 2.7: Internal with Interrupt  
np2_7 = NamedProc "p2_7" 
        (IntChoice (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)))


--03 External choice -----------------------------------------------------------------------------------  

-- Example 3.1 : External choice with prefix 
-- E? Invalid syntax, (p1 [] p2) -> p

-- Example 3.2: External choice with Internal choice 
np3_2  = NamedProc   "p3_2" 
         (ExtChoice (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 3.3: External choice with External choice 
np3_3  = NamedProc "p3_3" 
         (ExtChoice (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 3.4: External choice with Interleave 
np3_4  = NamedProc "p3_4" 
         (ExtChoice (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 3.5: External choice with Generallise parallel 
np3_5  = NamedProc   "p3_5" 
         (ExtChoice (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 3.6: External choice with Sequential composition 
np3_6  = NamedProc "p3_6" (ExtChoice (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 3.7: External choice with Sequential composition 
np3_7  = NamedProc "p3_7" 
         (ExtChoice (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


--04  Interleave ----------------------------------------------------------------------------------------
-- Example 4.1 : Interleave with prefix 
-- E? Invalid syntax,  (p1 [] p2) -> p


-- Example 4.2: Interleave with Internal choice 
np4_2  = NamedProc  "p4_2" 
         (Interleave (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 4.3: Interleave with External choice
np4_3  = NamedProc    "p4_3" 
         (Interleave   (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 4.4: Interleave with Interleave 
np4_4  = NamedProc  "p4_4" 
         (Interleave (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))

-- Example 4.5: Interleave with Generallise parallel 
np4_5  = NamedProc  "p4_5" 
         (Interleave (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 4.6: Interleave with Sequential composition 
np4_6  = NamedProc  "p4_6" 
         (Interleave (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))

-- Example 4.7: Interleave with Sequential composition 
np4_7  = NamedProc  "p4_7" 
         (Interleave (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


--05 Generallise parallel

-- Example 5.1 : Interleave with prefix 
-- E? Invalid syntax, (p1 [] p2) -> p


-- Example 5.2: Generallise parallel with Internal choice----------------------------------------------
np5_2  = NamedProc  "p5_2" 
         (GenPar (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP)) [ID "e1"])

-- Example 5.3: Generallise parallel with External choice----------------------------------------------
np5_3  = NamedProc  "p5_3" 
         (GenPar (Prefix (ID "e2") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP)) [ID "e2"]) 


-- Example 5.4: Generallise parallel with Interleave --------------------------------------------------
np5_4  = NamedProc  "p5_4" 
         (GenPar (Prefix (ID "e2") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e1") SKIP)) [ID "e2"])


-- Example 5.4a: Generallise parallel with Interleave --------------------------------------------------
-- p5_4a = (e2-> (SKIP))[|{e2}|]((e2-> (e3-> (SKIP)))|||(e2-> (e4-> (SKIP))))

np5_4a  = NamedProc  "p5_4a" 
--         (GenPar (Prefix (ID "e2") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)) [])
          (GenPar (Prefix (ID "e2") SKIP) (Interleave (Prefix (ID "e2") (Prefix (ID "e3") SKIP)) (Prefix (ID "e2") (Prefix (ID "e4") SKIP))) [ID "e2"])


-- Example 5.4a: Generallise parallel with Interleave --------------------------------------------------
np5_4b  = NamedProc  "p5_4b" 
          (GenPar (Prefix (ID "e2") (Prefix (ID "e2") SKIP)) (Interleave (Prefix (ID "e2") (Prefix (ID "e3") SKIP)) (Prefix (ID "e2") (Prefix (ID "e4") SKIP))) [ID "e2"])


-- Example 5.5: Generallise parallel with Generallise parallel ----------------------------------------
np5_5  =  NamedProc "p5_5" 
          (GenPar (Prefix (ID "e2") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [ID "e2"])


-- Example 5.6: Generallise parallel with Sequential composition --------------------------------------
-- p5_6 = (e1-> (SKIP))[|{e2}|]((e2-> (SKIP));(e3-> (SKIP)))
np5_6  =  NamedProc  "p5_6" 
          (GenPar (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [ID "e1"])

-- Example 5.6: Generallise parallel with Interrupt-----------------------------------------------------
np5_7  =  NamedProc  "p5_7" 
          (GenPar (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [ID "e1"])


-- Additional test examples for synchronisations
---------------------------------------------------------------------------
-- P01:  (cs->SKIP)[|{}|]((cs->SKIP) [|{}](cs->SKIP))  -- P ||| (Q ||| S)
nsp6_1   = NamedProc "sp6_1" (GenPar (Prefix (ID "cs") SKIP) (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) []) [])

---------------------------------------------------------------------------
-- P02: ((cs->SKIP)[|{}|] (cs->SKIP))[|{}](cs->SKIP)  -- (P ||| Q) ||| S
nsp6_2  = NamedProc "sp6_2" (GenPar (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) []) (Prefix (ID "cs") SKIP) [])

---------------------------------------------------------------------------
-- P03:  (cs->SKIP)[|{cs}|]((cs->SKIP) [|{}](cs->SKIP))  -- P |[{cs}]| (Q ||| S)
nsp6_3  = NamedProc "sp6_3" (GenPar (Prefix (ID "cs") SKIP) (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) [ID "cs"]) [])

---------------------------------------------------------------------------
-- P04: ((cs->SKIP)[|{cs}|] (cs->SKIP))[|{}|](cs->SKIP)  -- (P |[{cs}]| Q) ||| S
nsp6_4  = NamedProc  "sp6_4" (GenPar (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) [ID "cs"]) (Prefix (ID "cs") SKIP) [])


---------------------------------------------------------------------------
-- P05:  (cs->SKIP)[|{}|]((cs->SKIP) [|{cs}](cs->SKIP)) -- P ||| (Q |[{cs}]| S)
nsp6_5  = NamedProc "sp6_5" (GenPar (Prefix (ID "cs")     SKIP) 
         (GenPar (Prefix (ID "cs") SKIP)(Prefix (ID "cs") SKIP) [] ) [ID "cs"])


---------------------------------------------------------------------------
-- P06: ((cs->SKIP)[|{}|] (cs->SKIP))[|{cs}](cs->SKIP) -- -- (P ||| Q) |[{cs}]| S
nsp6_6  = NamedProc "sp6_6" (GenPar (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) []) 
          (Prefix (ID "cs") SKIP) [ID "cs"])

---------------------------------------------------------------------------
-- PO7:  (cs->SKIP)[|{cs}|]((cs->SKIP) [|{cs}](cs->SKIP))  --  P |[{cs}]| (Q |[{cs}]| S)
nsp6_7  = NamedProc  "sp6_7" (GenPar (Prefix (ID "cs") SKIP) (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) [ID "cs"]) [ID "cs"])


---------------------------------------------------------------------------
-- P08: ((cs->SKIP)[|{cs}|](cs->SKIP))[|{cs}](cs->SKIP)   --  (P |[{cs}]| Q) |[{cs}]| S
nsp6_8  = NamedProc "sp6_8" (GenPar (GenPar (Prefix (ID "cs") SKIP) 
          (Prefix (ID "cs") SKIP) [ID "cs"]) (Prefix (ID "cs") SKIP) [ID "cs"])

---------------------------------------------------------------------------
-- P09: ((cs->SKIP)[|{cs}|] (cs->SKIP))|||((cs1->SKIP)[|{cs1}|] (cs1->SKIP)) -- --  (P |[{cs}]| Q) ||\ (R |[{cs1}]| S)
nsp6_9  = NamedProc "sp6_9" (GenPar (GenPar (Prefix (ID "cs" ) SKIP) (Prefix (ID "cs" ) SKIP) [ID "cs" ]) 
          (GenPar (Prefix (ID "cs1") SKIP) (Prefix (ID "cs1") SKIP) [ID "cs1"]) [])


---------------------------------------------------------------------------
-- P10: ((cs->SKIP)[|{cs}|] (cs->SKIP))|||((cs->SKIP)[|{cs}|] (cs->SKIP))  -- (P |[{cs}]| Q) ||\ (R |[{cs}]| S)
nsp6_10  = NamedProc "sp6_10" (GenPar (GenPar (Prefix (ID "cs") SKIP) (Prefix (ID "cs") SKIP) [ID "cs"]) 
           (GenPar (Prefix (ID "cs") SKIP) (Prefix (ID "cs") SKIP) [ID "cs"]) [])

---------------------------------------------------------------------------
-- Todo: investigate infinite recursive concurrent
-- P1 = e1 -> e2 -> e1 -> e2 -> e1 -> P1     -- Infinite interleaving
-- pP1 = P1 ||| P1   

p6_11   =  (Prefix (ID "e1") (Prefix (ID "e2") (Prefix (ID "e1")  (Prefix (ID "e2") 
           (Prefix (ID "e1") SKIP )))))

nsp6_11 =  NamedProc  "sp6_11" (GenPar p6_11  p6_11  [] )


-- p6_11   =  NamedProc  "p6_11" (Prefix (ID "e1") (Prefix (ID "e2") (Prefix (ID "e1")  (Prefix (ID "e2") 
--           (Prefix (ID "e1") (ProcID "p6_11" ))))))

-- nsp6_11 =  NamedProc  "sp6_11" (GenPar (ProcID "p6_11")  (ProcID "p6_11")  [] )

---------------------------------------------------------------------------------------------------------
-- P1 = e1 -> e2 -> e1 -> e2 -> e1 -> P1    -- Infinite concurrency with single synchronisation
-- pP2 = P1 [|{e1}|]  P1   
nsp6_12 =  NamedProc  "sp6_12" (GenPar p6_11  p6_11  [ID "e1"] )
-- nsp6_12 =  NamedProc  "sp6_12" (GenPar (ProcID "p6_11")  (ProcID "p6_11")  [ID "e1"] )

---------------------------------------------------------------------------------------------------------
-- P1 = e1 -> e2 -> e1 -> e2 -> e1 -> P1   --  Infinite concurrency with multiple synchronisation
-- pP3 = P1 [|{e1, e2}|]  P1   

nsp6_13 =  NamedProc  "sp6_13" (GenPar  p6_11  p6_11  [ID "e1", ID "e2"] )

-- nsp6_13 =  NamedProc  "sp6_13" (GenPar (ProcID "p6_11")  (ProcID "p6_11")  [ID "e1", ID "e2"] )


-- Example for illustrating traces with different permutation
----------------------------------------------------------------------------------------------          
-- fp1 = (e1 -> e1 -> e1 -> e1 -> e1 -> SKIP) [] (e2 -> SKIP)    -- Exploring traces with various lengths
           
nsp6_14  =  NamedProc  "sp6_14"  
             (ExtChoice ((Prefix (ID "e1") (Prefix (ID "e1") (Prefix (ID "e1")  (Prefix (ID "e1") 
             (Prefix (ID "e1") SKIP )))))) (Prefix (ID "e2") SKIP))


----------------------------------------------------------------------------------------------
-- pp2 = e1 -> e2 -> e1 -> e2 -> e1 -> SKIP    -- Exploring traces with various permutations
-- fp2 = P1 ||| P1   

nsp6_15  =  NamedProc  "sp6_15" (GenPar pp2 pp2 [])
pp2      =  (Prefix (ID "e1") (Prefix (ID "e2") (Prefix (ID "e1")  (Prefix (ID "e2") 
            (Prefix (ID "e1") SKIP )))))
           

----------------------------------------------------------------------------------------------
-- 07 Sequential Composition

-- Example 7.1 : Interleave with prefix 
-- E? Invalid syntax,  (p1 [] p2) -> p


-- Example 7.2: Sequential Composition with Internal choice 
np7_2  = NamedProc  "p7_2" 
         (Seq (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 7.3: Sequential Composition with External choice
np7_3  = NamedProc  "p7_3" 
         (Seq   (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 7.4: Sequential Composition with Interleave 
np7_4  = NamedProc  "p7_4" 
         (Seq (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))

-- Example 7.5: Sequential Composition with Generallise parallel 
np7_5  = NamedProc  "p7_5" 
         (Seq (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))


-- Example 4.6: Sequential Composition with Sequential composition 
np7_6  = NamedProc  "p7_6" 
         (Seq (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 4.6: Sequential Composition with Interrupt
np7_7  = NamedProc  "p7_7" 
         (Seq (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Interrupt  Examples  ---------------------------------------------

-- Example 8.1 : Interrupt with prefix 
-- E? Invalid syntax, (p1 /\ p2) -> p, but change as (p1 /\ p2)

np8_1 = NamedProc "p8_1" (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) )
--np8_01 = NamedProc "p8_01" (Interrupt (Prefix (ID "e1") STOP) (Prefix (ID "e2") SKIP) )
-- np11 = (e1-> (STOP))/\(e2-> (SKIP))

-- Example 8.2: External choice with Internal choice 
np8_2  = NamedProc   "p8_2" 
         (Interrupt (Prefix (ID "e1") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 8.3: Interrupt with External choice 
np8_3  = NamedProc "p8_3" 
         (Interrupt (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


-- Example 8.4: Interrupt with Interleave 
np8_4  = NamedProc "p8_4" 
         (Interrupt (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)))


-- Example 8.5: Interrupt with Generallise parallel 
np8_5  = NamedProc   "p8_5" 
         (Interrupt (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]))

--np8_5  = NamedProc   "p8_5" 
--         (Interrupt (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP) []))


-- Example 8.6: Interrupt with Sequential composition 
np8_6  = NamedProc "p8_6" 
         (Interrupt (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))

-- Example 8.6: Interrupt with Sequential composition 
np8_7  = NamedProc "p8_7" 
         (Interrupt (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)))


--09 Timeout Examples -------------------------------------------------------------------------  

-- Basic timeout
np9_1 = NamedProc "p9_1" (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 2 )


-- Example 9.1 : Timeout with prefix 
-- E? Invalid syntax, (p1 |~| p2) -> p

-- Example 9.2: Timeout with Internal choice
np9_2  = NamedProc "p9_2" 
        (Timeout (Prefix (ID "e2") SKIP) (IntChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)) 2)


-- Example 9.3: Timeout with External choice
np9_3 = NamedProc "p9_3" 
        (Timeout (Prefix (ID "e1") SKIP) (ExtChoice (Prefix (ID "e2") SKIP) (Prefix (ID "e3") SKIP)) 2)


-- Example 9.4: Timeout with Interleave 
np9_4 = NamedProc "p9_4" 
        (Timeout (Prefix (ID "e1") SKIP) (Interleave (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP)) 2)

-- Example 9.5: Timeout with Generallise parallel 
np9_5 = NamedProc "p9_5" 
        (Timeout (Prefix (ID "e1") SKIP) (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) 2)


-- Example 9.6: Timeout with Sequential composition 
np9_6 = NamedProc "p9_6" 
        (Timeout (Prefix (ID "e1") SKIP) (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  2)


-- Example 9.7: Timeout with Interrupt  
np9_7 = NamedProc "p9_7" 
        (Timeout (Prefix (ID "e1") SKIP) (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) 2)


-- Example 9.8: Timeout with Timeout  
np9_8 = NamedProc "p9_8" 
        (Timeout (Prefix (ID "e1") SKIP) (Timeout (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP) 1)  2)
-- p9_8 = (e1-> (SKIP))[5>((e1-> (SKIP))[3>(e2-> (SKIP)))


-- Hiding ---------------------------------------------------------------------------------
-- Hiding a single events in np***, multiple events np***m and empty events np***e

-- Hiding with prefix
np10_1  = NamedProc "p10_1" 
         (Hiding (Prefix (ID "e1") SKIP) [(ID "e1")])
         
-- Hiding multiple events
np10_1m  = NamedProc "p10_1m" 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2") ])

-- Hiding empty events
np10_1e  = NamedProc "p10_1e" 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [ ])
         


-- Example 3.2: Hiding with Internal choice 
np10_2  = NamedProc   "p10_2" 
         (Hiding (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1")]  )

np10_2m  = NamedProc   "p10_2m" 
         (Hiding (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")] )

np10_2e  = NamedProc   "p10_2e" 
         (Hiding (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) []  )


-- Example 3.3: Hiding with External choice 
np10_3  = NamedProc "p10_3" 
         (Hiding (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1")]  )
         
np10_3m  = NamedProc "p10_3m" 
         (Hiding (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")]  )

np10_3e  = NamedProc "p10_3e" 
         (Hiding (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) [ ]  )
         

-- Example 3.4: Hiding with Interleave 
np10_4  = NamedProc "p10_4" 
         (Hiding (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1")] )

np10_4m  = NamedProc "p10_4m" 
         (Hiding (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1"), (ID "e1")] )

np10_4e  = NamedProc "p10_4e" 
         (Hiding (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [ ] )


-- Example 3.5: Hiding with Generallise parallel 
np10_5   = NamedProc   "p10_5" 
         (Hiding (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [(ID "e2")]  )

np10_5m  = NamedProc   "p10_5m" 
         (Hiding (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [(ID "e2"), (ID "e2")]  )

np10_5e  = NamedProc   "p10_5e" 
         (Hiding (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"]) [ ]  )


-- Example 3.6: Hiding with Sequential composition 
np10_6   = NamedProc "p10_6" 
         (Hiding (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1")]  )

np10_6m  = NamedProc "p10_6m" 
         (Hiding (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1"), (ID "e2")]  )

np10_6e  = NamedProc "p10_6e" 
         (Hiding (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [ ]  )


-- Example 3.7: Hiding with Sequential composition 
np10_7   = NamedProc "p10_7" 
         (Hiding (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1")]    )

np10_7m  = NamedProc "p10_7m" 
         (Hiding (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [(ID "e1"), (ID "e2")]    )

np10_7e  = NamedProc "p10_7e" 
         (Hiding (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  [ ]    )


-- Additional examples for hiding in one side of binary operators   -----------
-- The examples involve hiding single event, multiple events and empty events

-- Example 3.2: Hiding in one side of internal choice 
np10_2s   = NamedProc   "p10_2s" 
         (IntChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP))

np10_2ms  = NamedProc   "p10_2ms" 
         (IntChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP))

np10_2es  = NamedProc   "p10_2es" 
         (IntChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [ ])
         (Prefix (ID "e2") SKIP))


-- Example 3.3: Hiding in one side of external choice 
np10_3s  = NamedProc "p10_3s" 
         (ExtChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP))
         
np10_3ms  = NamedProc "p10_3ms" 
         (ExtChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP))


np10_3es  = NamedProc "p10_3es" 
         (ExtChoice 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [ ])
         (Prefix (ID "e2") SKIP))
         

-- Example 3.4: Hiding in one side of Interleave
np10_4s  = NamedProc "p10_4" 
         (Interleave
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP))         

np10_4ms  = NamedProc "p10_4m" 
         (Interleave 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP))


np10_4es  = NamedProc "p10_4e" 
         (Interleave 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [])
         (Prefix (ID "e2") SKIP))


-- Example 3.5: Hiding in one side of Generallise parallel 
np10_5s   = NamedProc   "p10_5" 
         (GenPar
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         [(ID "e2")] 
         )

np10_5ms  = NamedProc   "p10_5m" 
         (GenPar
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         [(ID "e2")] 
         )

np10_5es  = NamedProc   "p10_5e" 
         (GenPar
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [])
         (Prefix (ID "e2") SKIP)
         [(ID "e2")] 
         )



-- Example 3.6: Hiding in one side of sequential composition 
np10_6s   = NamedProc "p10_6" 
         (Seq 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP)
         )

np10_6ms  = NamedProc "p10_6m" 
         (Seq 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         )

np10_6es  = NamedProc "p10_6e" 
         (Seq 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [])
         (Prefix (ID "e2") SKIP)
         )


-- Example 3.7: Hiding in one side of Interrupt composition 
np10_7s   = NamedProc "p10_7" 
         (Interrupt 
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1")])
         (Prefix (ID "e2") SKIP)
         )


np10_7ms  = NamedProc "p10_7m" 
         (Interrupt
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [(ID "e1"), (ID "e2")])
         (Prefix (ID "e2") SKIP)
         )

np10_7es  = NamedProc "p10_7e" 
         (Interrupt
         (Hiding (Prefix (ID "e1") (Prefix (ID "e2") SKIP)) [] )
         (Prefix (ID "e2") SKIP)
         )


-- Renaming  ------------------------------------------------------------------
-- Renaming with prefix
np11_1  = NamedProc "p11_1" 
         (Rename (Prefix (ID "e1") SKIP) 
         [((ID "e1"), (ID "e3"))])


-- Example 3.2: Hiding with Internal choice 
np11_2  = NamedProc   "p11_2" 
         (Rename (IntChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) 
         [((ID "e1"), (ID "e3"))] )


-- Example 3.3: Hiding with External choice 
np11_3  = NamedProc "p11_3" 
         (Rename (ExtChoice (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) 
         [((ID "e1"), (ID "e3"))]  )


-- Example 3.4: Hiding with Interleave 
np11_4  = NamedProc "p11_4" 
         (Rename (Interleave (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) 
         [((ID "e1"), (ID "e3"))]  )


-- Example 3.5: Hiding with Generallise parallel 
np11_5  = NamedProc   "p11_5" 
         (Rename (GenPar (Prefix (ID "e2") SKIP) (Prefix (ID "e2") SKIP) [ID "e2"])  
         [((ID "e1"), (ID "e3"))]  )


-- Example 3.6: Hiding with Sequential composition 
np11_6  = NamedProc "p11_6" 
         (Rename (Seq (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP)) 
         [((ID "e1"), (ID "e3"))] )


-- Example 3.7: Hiding with Sequential composition 
np11_7  = NamedProc "p11_7" 
         (Rename (Interrupt (Prefix (ID "e1") SKIP) (Prefix (ID "e2") SKIP))  
         [((ID "e1"), (ID "e3"))]   )

-- Other test cases -----------------------------------------------------
-- p12_1 = (STOP)[|{c1}|]((c-> (SKIP))/\(c1-> (SKIP)))
np12_1  = NamedProc  "p12_1" 
         (GenPar  STOP 
         (Interrupt (Prefix (ID "c") SKIP) (Prefix (ID "c1") SKIP) ) 
         [ID "c1"])

-- p12_2 = (e1-> (SKIP))/\(((e1-> (SKIP))[|{e1}|](STOP))[|{}|](e2-> (SKIP)))
np12_2  = NamedProc   "p12_2" 
         (Interrupt 
         (Prefix (ID "e1") SKIP) 
         (GenPar 
         (GenPar 
         (Prefix (ID "e1") SKIP)  STOP   [ID "e1"])
         (Prefix (ID "e2") SKIP)  [ ]))

---------------------------------------------------------------------------------
-- Simplified specification of RoboChart model of a simple moving forward system.
-- A timed version model of tock-CSP suitable for timed section of FDR
---------------------------------------------------------------------------------

{-
Tspec = EntryMoving; obstacle-> SKIP0; EntryTurning; Countdown(SMovement_PI/SMovement_av); Tspec

EntryMoving = EDeadline(moveCall, 0); EDeadline(moveRet, 0); Countdown(1) 

EntryTurning = EDeadline(moveCall, 0); EDeadline(moveRet,0) 
-}

-- Tspec = EntryMoving; obstacle-> SKIP0; EntryTurning; Countdown(SMovement_PI/SMovement_av); Tspec
np12_4 = NamedProc "Tspec" 
           (Seq 
           (Seq (entryMovingT)
           (Seq (Prefix (ID "obstacle") SKIP0 ) 
           (Seq (entryTurningT)  (Countdown 3)
           )))
           (ProcID "Tspec")
           )
           
-- EntryMoving = EDeadline(moveCall, 0); EDeadline(moveRet, 0); WAIT(1) 
entryMovingT  = Seq 
               (EDeadline (ID "moveCall")  0)
               (Seq (EDeadline (ID "moveRet")  0)  (Countdown 1))


-- EntryTurning = EDeadline(moveCall, 0); EDeadline(moveRet,0) 
entryTurningT = Seq 
               (EDeadline (ID "moveCall")  0)
               (EDeadline (ID "moveRet" )  0)
               


---------------------------------------------------------------------------------
-- Simplify specifications of obstacle detection system
---------------------------------------------------------------------------------
{-
channel moveCall, moveRet, obstacle, tock
-- Constant values from the model
SMovement_PI = 10
SMovement_av = 5

Spec = EntryMoving; Obs; EntryTurning; wait(SMovement_PI/SMovement_av); Spec
-- The delay associated with EntryMoving avoids a possible requirement for the
-- two move operations in the same cycle. 
EntryMoving = moveCall -> moveRet -> |~| i: {1..10} @ wait(i)
Obs = obstacle -> SKIP [] tock ->  Obs
EntryTurning = moveCall -> moveRet -> SKIP

wait(n) = if n == 0 then SKIP else tock -> wait(n-1)

assert Spec :[deadlock free]
assert Spec :[deterministic]
assert Spec :[divergence free]

-- The short specification is a correct semantics of the RoboChart model. 
-- assert Spec [FD= T_CFootBot
-- assert T_CFootBot [FD= Spec
-}

----------------------------------------------------------------------
-- Init attempt for translating RoboChart
-- Spec = EntryMoving; Obs; EntryTurning; wait(SMovement_PI/SMovement_av); Spec
np12_3 = NamedProc "Spec" 
           (Seq entryMoving
           (Seq obs
           (Seq entryTurning 
           -- SMovement_PI/SMovement_av = 45/15
           (Seq (Wait 3) (ProcID "Spec") ))))

--EntryMoving = moveCall -> moveRet -> |~| i: {1..10} @ wait(i)
-- NamedProc "EntryMoving"
--           (Prefix (ID "moveCall) (Prefix (ID "moveRet") 
entryMoving  = (Prefix (ID "moveCall") (Prefix (ID "moveRet") 
           (IntChoice  (Wait 1)
           (IntChoice  (Wait 2)
           (IntChoice  (Wait 3)
           (IntChoice  (Wait 4)
           (IntChoice  (Wait 5)
           (IntChoice  (Wait 6)
           (IntChoice  (Wait 7)
           (IntChoice  (Wait 8)
           (IntChoice  (Wait 9)  (Wait 10)
           ))))))))))
           ) 


-- Obs = obstacle -> SKIP [] tock ->  Obs
-- NamedProc "Obs" 
--         (ExtChoice
obs =    (ExtChoice         
         (Prefix (ID "obstacle") SKIP )
         (Prefix (ID "tock")  (ProcID "Obs"))
         )

-- EntryTurning = moveCall -> moveRet -> SKIP
-- NamedProc  "EntryTurning"
entryTurning = (Prefix (ID "moveCall")  
               (Prefix (ID "moveRet") SKIP )
               )



