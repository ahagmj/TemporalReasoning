-- Structure of the file
-- This program generates monitors for verifying traces.

--------------------------------------------------------------------
import System.Environment   
import System.Directory  
import System.IO  
import TA
import Data.List.Split
import Data.Char
import qualified Data.ByteString.Char8 as B


main = do 
       -- traceID, trace, directory, process name from the arguments 
       [traceNo, trace, dr, taFile, pName] <- getArgs
       ta                                  <- B.readFile taFile
       B.writeFile (dr ++ "/monitor_t"++ traceNo ++ "_" ++ pName ++ ".xml") 
                   (B.pack (addMonitor ((B.unpack ta), (show (genMonitor pName trace)))))



--  This function takes a collection of TAs for a process and replace its TA env with TA monitor
addMonitor :: (String, String) -> String
addMonitor    (ta,    monitor)  = (ls !! 0) ++ "// template for Env begins"  ++     
                                              -- with Env to corresponds with remaining code
                                  monitor   ++ "// template for Env ends"    ++  --  (ls1!!1)
                                  (ls2!!0)  ++ "<queries>\n<query><formula> E&lt;&gt; pEnv.sf"  ++
                                  "\n</formula>\n<comment>"                  ++     (ls3!!1) 
                                  where
                                        -- split and remove the TA for Env
                                        ls  = splitOn "// template for Env begins"  ta   
                                        ls1 = splitOn "// template for Env ends"    ta
                                        -- split and modify the query into, "can the Env reach a final state?"
                                        ls2 = splitOn "<queries>\n<query><formula>" (ls1!!1)
                                        ls3 = splitOn "</formula>\n<comment>"       (ls1!!1)
                                    
   
-- This function takes trace and returns a TA monitor for replacing the environment
genMonitor :: String -> String -> Template
genMonitor    pid         s    = Template "Env" [] [] locs [] (Init (head locs)) trans
                           where
                                -- extracts the event names from the traces
                                events = (splitOn ","  (tail $ init (itrim s)))   
                                -- convert the trace into states id and replace the final state
                                locs   = (addStates (init events)) ++ 
                                        [(Location ('s':e) ('s':e) EmptyLabel None) | e <- ["0", "f"] ] 
                                        -- add initial and final states
                                -- add transitions to connect the state into a TA
                                trans  = (addTransition events locs) ++ (concat (map (addTranss pid) locs))
--                                trans  = (addTransition events locs) ++ (concat (map (addTranss pid) locs))
                                                              -- flatten this



-- This function takes a state s and returns its AST constructs
addState ::  String -> Location
addState s = Location s s EmptyLabel None


-- This function takes the name of the events and creates their corresponding locations 
addStates :: [String] -> [Location]
addStates    es       =  [(Location ('s':((show n) ++ e)) ('s':((show n) ++ e)) EmptyLabel None)|(e, n) <- zip es [1.. ] ]



-- This function takes traces with locations' ID and then generates sequence of transitions to connect the locations
addTransition :: [String] -> [Location] -> [Transition]
addTransition    []          []          = []
addTransition    []          xs          = []
addTransition    ["tick"]    (s1:s2:xs)  = [(Transition s1 s2 [(Sync (VariableID "tick"      []) Ques)] [])] 
addTransition    (e:es)      (s1:s2:xs)  = (if e == "tock" 
                                           then [(Transition s1 s2 [(Sync (VariableID e      []) Excl)] [])]
                                           else [(Transition s1 s2 [(Sync (VariableID e      []) Ques)] [])] )
                                           ++ (addTransition es (s2:xs))
                                           

-- This function adds transitions for connecting states (locations)
addTranss :: String -> Location ->    [Transition]
addTranss    pid       s        =     [Transition s s [(Sync   (VariableID  "startID00"               [])  Excl),
                                             (Guard     (BinaryExp  (ExpID   "start")  Equal      (Val 0))),
                                             (Update   [(AssgExp    (ExpID   "start")  ASSIGNMENT (Val 1))])]  [], 
                                      Transition  s s  [(Sync   (VariableID ("startID" ++ pid)        [])  Excl),
                                             (Guard     (BinaryExp  (ExpID   "start")  Equal      (Val 0))),
                                             (Update   [(AssgExp    (ExpID   "start")  ASSIGNMENT (Val 1))])]  [], 
                                      Transition  s s  [(Sync   (VariableID  "finishID0" [])  Ques)]  [],  --,
                                      Transition  s s  [(Sync   (VariableID  "tick"      [])  Ques)]  [],  -- ,  
                                     Transition  s s  [(Sync   (VariableID  "tock"      [])  Excl),                 
                                             (Guard $  BinaryExp    (ExpID    "ck"  )  Lte         (Val 1)), 
                                             (Update   [AssgExp     (ExpID    "ck"  )  ASSIGNMENT  (Val 0)] )] []
                                      ]


-- Removes empty spaces
itrim :: String -> String
itrim    []     =  []
itrim    (x:xs) =  if isSpace x then itrim xs
                   else [x] ++ (itrim xs)

-----------------------------------------------------------------------------
{-
--Brief structure of the algorithm
input traceID, trace, directory, process name from the arguments 
output TA files with TA monitor replaced TA Env

Gen TA monitor 
    Add starting state
    For  each event in trace
        Add state s, if final state sf
        add transition from the last state to new state with action event
        
Update the original TA with the monitor and
        add new query (can the monitor reach final state)
-}
-----------------------------------------------------------------------------


