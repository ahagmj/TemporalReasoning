--File Structure
--  Brief descriptions
--  Definitions

-- todo update: import genmonitors.hs and remove repeated functions 


------------------------------------------------------------------------------
import System.Environment   
import System.Directory  
import System.IO  
import TA
import TF
import CSP
import Data.List
import Data.List.Split
import Data.Char
import qualified Data.ByteString.Char8 as B
import System.Environment   


main = do 
       [traceFileFDR, eventsFile, taFile, dr, traceSizeString] <- getArgs
       trace     <- B.readFile traceFileFDR
       events    <- B.readFile eventsFile  
       ta        <- B.readFile taFile  
       
       -- Get trace size
--       traceText  <- readFile "traceSizeFile"
       let traceSize = read traceSizeString
       
       -- Create directory for the forbidden initials
       createDirectoryIfMissing True  (dr ++ "/ForbiddeInits") 

          
       -- set of traces with the added forbidden intials
       B.writeFile (dr ++ "/ForbiddeInits/traceWithForbiddenInit") 
                   (B.pack $ fst (genMonitorTrace traceSize (B.unpack trace)  (B.unpack events)  (B.unpack ta)  dr ))

       -- generate TA monitor for each trace into a file monitorTrace1, monitorTrace2, monitorTrace3 and so on
       sequence  [ B.writeFile (dr ++ "/ForbiddeInits/monitorTrace" ++ (show n) ++ ".xml" )   (B.pack ta ) |  
          (ta, n) <- zip (snd (genMonitorTrace traceSize (B.unpack trace)  (B.unpack events)  (B.unpack ta)  dr)) [1..]]


----------------------------------------------------------------------------------------------
--                 traceSize -> trace  -> event  -> TA     -> directory -> (newtrace, taMonitor)
genMonitorTrace :: Int       -> String -> String -> String -> String    -> (String,   [String] )
genMonitorTrace    traceSize    s1        s2        ta        pdr     = 
                   ((ishowLinesSt (map ishowListSt newTrace)), monitorTAs)
                   where ts1       = (replace "itick"  "tick" s1)
                         trace     = [(splitOn ","  (tail $ init (itrim t))) | t <- lines ts1 ]
                         events    = removesTick (lines s2)   -- removes all tick events from forbidden events
                         -- new traces with the addition of every event to generate traces
                         -- including traces that are longer then the specify trace size
                         newTraceL = (uniq ([t ++ [e] | t <- trace, e <- (uniq events), ((length t) < traceSize) ] 
--                                      (not $ elem (t ++ [e]) trace) ]
                                     ++ [[e] | e <- (uniq events) ]) )  \\ trace
                                     
                         subtractT = subtractTraces newTraceL trace             

                         -- remove traces that are longer then the provided trace size n
                         newTrace  = removeLongerTrace newTraceL  traceSize     -- for now trace size as 5,    

--                                 newTrace  = removeLongerTrace newTraceL  5       -- for now trace size as 5,    
--                                             TODO 
                         -- generates monitor for each trace [monitors]
--                                             monitors1 = [(genMonitor  ("monitorTrace" ++ (show pid))  es) |

                         -- Extract process ID from its directory name and generates the monitors
                         pid        = last (splitOn "/" pdr) 
                         monitors1  = [(genMonitor  pid  es) | es <- newTrace ]
                         
                         -- append each one to the TA [TAs]
                         monitorTAs = [addMonitor  (ta,  (show monitor)) | monitor <- monitors1 ]
                         

-----------------------------------------------------------------------------------------------------
--  takes collection of TAs for a process and replace its TA env with TA monitor and a new querry, which asks if the monitor can reach its final state sf.
addMonitor :: (String, String) -> String
addMonitor    (ta,    monitor)  = (ls !! 0) ++ "// template for Env begins" ++     
                                              -- with Env to corresponds with remaining code
                                  monitor   ++ "// template for Env ends"   ++  --  (ls1!!1)
                                  (ls2!!0)  ++ "<queries>\n<query><formula> E&lt;&gt; pEnv.sf"  ++
                                  "\n</formula>\n<comment>"                 ++ (ls3!!1) 
                                  where
                                    -- split and remove the TA for Env
                                    ls  = splitOn "// template for Env begins"  ta   
                                    ls1 = splitOn "// template for Env ends"    ta
                                    -- split and modify the query, can the Env reach a final state
                                    ls2 = splitOn "<queries>\n<query><formula>" (ls1!!1)
                                    ls3 = splitOn "</formula>\n<comment>"       (ls1!!1)



-- takes trace and return its TA monitor
genMonitor :: String -> [String]  -> Template
genMonitor    pid       events    = Template "Env" [] [] locs [] (Init (head locs)) trans
                                    where
    --                                events = ["s0"] ++ (splitOn ","  (tail $ init (itrim s)))    
                                    -- events = (splitOn ","  (tail $ init (itrim s)))   
                                    -- convert the trace into states id and replace the final state
--                                    locs   = addStates ((init events) ++ ["0", "f"])       -- possibly to replace with
                                    locs   = (addStates (init events)) ++ initFinalStates  -- possibly to replace with
                                    trans  = (addTransition events locs) ++ (concat (map (addTranss pid) locs))
                                                              -- flatten this
                                    -- add initial and final states separately
                                    initFinalStates =  [(Location ('s':e) ('s':e) EmptyLabel None) | e <- ["0", "f"] ]

----------------------------------------------------------------------------
-- todo: addState, addTranss and addTransition are similar to genmonitor.hs, to consider importing them for improvement

-- add states with the events' names, and returns its AST constructs
addStates :: [String]  -> [Location]
addStates    es        =  [(Location ("s" ++ (show n) ++ "_" ++ e)  ("s" ++ (show n) ++ "_" ++ e) EmptyLabel None) 
                            | (e, n) <- (zip es [1..(length es)]) ]
-- addStates    es        =  [(Location ('s':e) ('s':e) EmptyLabel None) | e <- es ]


-- takes trace and add sequence transitions for its events
            --   [events]  -> [states] 
addTransition :: [String] -> [Location] -> [Transition]
addTransition    []          []          = []
addTransition    []          xs          = []
addTransition    (e:es)      (s1:s2:xs)  = (if e == "tock" 
                                           then [(Transition s1 s2 [(Sync  (VariableID e []) Excl )] [])]
                                           else [(Transition s1 s2 [(Sync (VariableID e []) Ques)] [])]) 
                                           ++ (addTransition es (s2:xs)) 


-- add the remaining transition for each states
addTranss :: String -> Location ->    [Transition]
addTranss    pid       s        =     [Transition  s s [(Sync   (VariableID "startID00"        [])  Excl),
                                             (Guard     (BinaryExp (ExpID "start")  Equal      (Val 0))),
                                             (Update   [(AssgExp   (ExpID "start")  ASSIGNMENT (Val 1))])]  [], 
                                      Transition  s s  [(Sync   (VariableID ("startID" ++ pid)        [])  Excl),
                                             (Guard     (BinaryExp (ExpID "start")  Equal      (Val 0))),
                                             (Update   [(AssgExp   (ExpID "start")  ASSIGNMENT (Val 1))])]  [], 
                                      Transition  s s  [(Sync   (VariableID "finishID0" [])  Ques)] [], -- ,
                                      Transition  s s  [(Sync   (VariableID "tick"      [])  Ques)] [], --,  
                                      Transition  s s  [(Sync   (VariableID "tock"      [])  Excl),                 
                                             (Guard  $ BinaryExp   (ExpID "ck"   )  Lte         (Val 1)), 
                                             (Update   [AssgExp    (ExpID "ck"   )  ASSIGNMENT  (Val 0)] )] []
                                      ]

------------------------------------------------------------------------------------ 

-- trace subtraction
subtractTraces :: Eq a => [[a]] -> [[a]]  -> [[a]]
subtractTraces            []       _      =  []
subtractTraces            (t:ts)   traces =  if elem t traces then subtractTraces ts traces
                                             else t:(subtractTraces ts traces)


-- remove traces that are longer then the provided size of trace
removeLongerTrace :: Eq a => [[a]]    -> Int -> [[a]]
removeLongerTrace             []        _    =  []
removeLongerTrace             (t:ts)    n    =  if  (length t) <= n then (t:(removeLongerTrace ts n))
                                                else removeLongerTrace ts n


-- Removes empty spaces
itrim :: String -> String
itrim    []     =  []
itrim    (x:xs) =  if isSpace x then itrim xs
                   else [x] ++ (itrim xs)
                   
replace old new = intercalate new . splitOn old         

removesTick :: [String] -> [String]
removesTick    []       =  []
removesTick    (x:xs)   =  if x == "tick" then removesTick xs
                           else  (x:(removesTick xs))         

