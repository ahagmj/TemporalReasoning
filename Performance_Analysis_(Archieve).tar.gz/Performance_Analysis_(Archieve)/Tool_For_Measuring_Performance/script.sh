#-- Bash script for comparing FDR and UPPAAL traces.
#!/bin/bash


#--------------------------------------------------
#Definition of a function for generating FDR traces
function generateTracesFDR() {

    # Invokes FDR for generating traces ---------- 
    refines --format json  "$2"/"$1".csp 1>  "$2"/"$1"fdr.json

    # Extracts the relevant parts of the trace file by splitting the trace file on the following strings:
    # (?<=result":), (?=,"visited_states), (?<="trace":), ((?=,"states")|(?=}}]}],"print)), (?<="event_map": {) 
    # and  (?=},"warnings").
    # ${i%%/*}/trace: extracts the corresponding directory name from the trace file 
    (grep -o -P '(?<=result":).*(?=,"visited_states)|(?<="trace":).*((?=,"states")|(?=}}]}],"print))|(?<="event_map": {).*(?=},"warnings")' | sed 's|\"||g') <"$2"/"$1"fdr.json   >"$2"/tmp

          
    # Invokes Haskell program for assembling a trace
    runhaskell traceFDR.hs "$2"/tmp   "$2"          
    echo "Generating FDR traces ... completed " 
           
    #Todo: possible improvement for performance.
    #Instead of reading file, to consider passing the string directly to traceTA.hs
           
    #Copy the summary of all the trace information to a file testresult
    cat "$2"/trace >>     "$2"/traceResult   #GenFiles/traceResult
}
# End of the function generateTracesFDR

#------------------------------------------------
# Genarate FDR traces----------------------------
# for each file in the folder, do the following
folder=0
for d in `find GenFiles/*/FDR/* -type d`; do
    
    ((folder++))
    #Generate first trace using the function generateTraces, defined above.
    generateTracesFDR  $(basename $d)  $d

    tc=0
    # While FDR produces new trace, convert the trace into process, and update the assertion to generate another trace.
    while  grep -q "FDR trace" "$d"/trace  ; do    
        tc=$(($tc + 1))

        # Update CSP file, convert trace into process and update the assertion of the CSP file.
        echo "$folder : $tc : Updating CSP process for $(basename $d)"
        runhaskell trace2ProcFDR.hs  "$d"/$(basename $d).csp   "$d"/trace      

        #Generate new trace using the function generateTraces, defined above.
        generateTracesFDR $(basename $d) $d

    #end while loop
    done

#end for loop
done

#-------------------------------------------------------------------------
#Copy all the traces into one file GenFilesresult, at the top level folder
#cat */*/testresult >> testresult
for i in GenFiles/*/FDR/ ; do
    cat $i/*/traceResult  >> $i/traceResult
    # Separates the traces with the following string
    #echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" >> GenFiles/traceResult
done


#Select all the traces as lines (suitable for list)
for i in GenFiles/*/FDR/ ; do
    grep "]$"   <$i/traceResult  >$i/traceResFDR
done    


#Convert the trace list into set, this is provided for the purpose of debugging.
#for i in GenFiles/*/FDR/ ; do
#runhaskell traceSet.hs  $i/traceResFDR    $i
#done

# Finish generating FDR traces ----------------------------------------------------------------


# Generate UPPAAL traces ----------------------------------------------------------------------
# Function for generating UPPAAL traces
function generateTracesUPPAAL() {

      #Invokes UPPAAL engine verifyta for generating traces
      ./verifyta -t1 -X  "$2"/"$1"uppaal.xml  "$2"/"$1".xml
      
      #Extract UPPAAL traces
      #Extract edges from the trace file
      echo ${i%%.*}uppaal.xml1.xml
      ((sed 's|</|\n|g' | grep -o -P '(?<=<sync>).*|(?<=<edge id=").*(?=" from=)') | sed 's|\n+|,|g' )   <"$2"/"$1"uppaal.xml1.xml  >"$2"/tmp    

     #Extract the corresponding transitions
((sed 's|<transition|\n|g' | grep -o -P '(?<= edges=").*(?="/>)') | sed 's|\n+|,|g' )   <"$2"/"$1"uppaal.xml1.xml  >"$2"/tmpT    


     #Extract path auxiliary for generating subsequent trace, and store them in file tmp1
     (sed 's|</|\n|g' | grep -o -P '(?<=dp \+= 1,).*(?= := true)') <"$2"/"$1"uppaal.xml1.xml  >"$2"/tmp1     
#     (sed 's|</|\n|g' | grep -o -P '(?<=<update>dp \+= 1,).*(?= := true)') <"$2"/"$1"uppaal.xml1.xml  >"$2"/tmp1

}

#------------------------------------------------
    for d in `find GenFiles/*/Uppaal/* -type d`; do

        #Generate trace using the function generateTracesUPPAAL
        generateTracesUPPAAL      $(basename $d) $d
        runhaskell traceUPPAAL.hs "$d"/tmp      "$d"/tmpT   $d
        #tmpT for transitions

        #Generate trace until there is no new trace.
        while [ -e "$d"/"$(basename $d)"uppaal.xml1.xml ] ; do

            # Update TA
            echo updates TA
            runhaskell UpdateTA.hs  "$d"/$(basename $d).xml   "$d"/tmp1           


            #Delete the trace file
            echo deleting the file "$d"/"$(basename $d)"uppaal.xml1.xml
            [ -e "$d"/"$(basename $d)"uppaal.xml1.xml ] && rm "$d"/"$(basename $d)"uppaal.xml1.xml
            
            #Generate new set of trace using the function generateTraces, defined above.
            generateTracesUPPAAL      $(basename $d)  $d 
            runhaskell traceUPPAAL.hs "$d"/tmp       "$d"/tmpT  $d

        #end while loop
        done
    
        
    #end inner for loop
    done


#Copy all the UPPAAL traces into one file GenFiles/*/Uppaal/traceResUPPAAL, at the top level folder
for i in GenFiles/*/Uppaal ; do
    cat $i/*/traceRes >> $i/traceResUPPAAL
done


#Convert the traces into set and compare them
for i in GenFiles/* ; do
    runhaskell compareSetTraces.hs  $i/FDR/traceResFDR  $i/Uppaal/traceResUPPAAL   $i  $(basename $i)
#runhaskell compareSetTraces.hs  GenFiles/*/FDR/traceResFDR  GenFiles/*/Uppaal/traceResUPPAAL   GenFiles
done



#----- Verification with monitor TA --------------------------------------------------
# Function for converting trace into TA monitor to replace the TA 
# The function takes a trace and produces a corresponding TA environment for the trace.
function genMonitorFun(){

    lineNo=1
    while IFS='' read -r line || [[ -n "$line" ]]; do
        echo "Text read from file: $line" $lineNo
        runhaskell genMonitor.hs  "$lineNo" "$line"   $3  $2     $(basename $(dirname $3))
                              #    [lineNo, trace,    dr, taFile, pName] <- getArgs
        lineNo=$(($lineNo + 1))
    done < $1
}


# This code invokes the function genMonitorFun.
for i in GenFiles/*/monitor ; do
     genMonitorFun  $i/traceForMonitor*  $i/*TA.xml   $i
done


# Invokes Uppaal to verify the constructed TA from the trace.
for d in GenFiles/*/monitor/monitor* ; do

      ./verifyta -t1 -X  "$d"trace  $d

      #Extract edges of the TA monitor
      ((sed 's|</|\n|g' | grep -o -P '(?<=<sync>).*|(?<=<edge id=").*(?=" from=)') | sed 's|\n+|,|g' )  \
       <"$d"trace1.xml  >"$(dirname $d)"/tmp    

      #Extract transitions of the TA monitor
      ((sed 's|<transition|\n|g' | grep -o -P '(?<= edges=").*(?="/>)') | sed 's|\n+|,|g' )  \
      <"$d"trace1.xml  >"$(dirname $d)"/tmpT    

      #Map the transtion with edges to generate trace
      runhaskell traceUPPAAL.hs "$(dirname $d)"/tmp   "$(dirname $d)"/tmpT   $(dirname $d)
done


#Update trace result with verification result using monitor
for i in GenFiles/* ; do
      if [ -s $i/monitor/traceForMonitor* ] 
      then
          echo $'\n\n\n'$(basename $i)" TA monitor verifies the traces :" $'\n'{ >> $i/traceSetComparison
          cat $i/monitor/traceRes >> $i/traceSetComparison
          echo "}" >> $i/traceSetComparison     
      fi
done

#-----End of verification with monitor----------------------------------------------




# Source additional bash script for exhaustive testing with monitor.
source ForbiddenMonitor.sh


#Initialises counter for process with (non)similar traces from both FDR and UPPAAL
similarTrace=0
nonsimilarTrace=0


#-----------------------------------------------------------------------------------
#Copy all the trace comparisons of all processes into one file
for i in GenFiles/* ; do
    # Separate the traces with the following string
    echo $'\n\n'$(basename $i)"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" >> GenFiles/traceComparisonsAll

    #Copy process syntax from file
    cat $i/FDR/syntax >> GenFiles/traceComparisonsAll
           
    # Copy the results of each process into one file
    cat $i/traceSetComparison >> GenFiles/traceComparisonsAll
    
    if  grep -q "FDRtraces == UPPAALtraces"  "$i"/traceSetComparison  ;
    then
        similarTrace=$(($similarTrace + 1))
    fi
    
    if  grep -q "FDRtraces != UPPAALtraces"  "$i"/traceSetComparison  ;
    then
        nonsimilarTrace=$(($nonsimilarTrace + 1))
        echo $'\n\n'$(basename $i)"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" >> GenFiles/diffrentTraces
        cat  $i/FDR/syntax           >> GenFiles/diffrentTraces
        cat "$i"/traceSetComparison  >> GenFiles/diffrentTraces
    fi

done


    # Summary of all the processes
    echo $'\n\n' "Summary of the results for trace length $traceSize  -----------------" >> GenFiles/traceComparisonsAll
    if [ "$similarTrace" -eq 1 ] ;
    then     
        echo $similarTrace "process has the same traces for both FDR and UPPAAL"    >> GenFiles/traceComparisonsAll
    else
        echo $similarTrace "processes have the same traces for both FDR and UPPAAL" >> GenFiles/traceComparisonsAll
    fi
    
    if [ "$nonsimilarTrace" -eq 1 ] ;
    then
        echo $nonsimilarTrace "process has different traces for FDR and UPPAAL"    >> GenFiles/traceComparisonsAll
    else
        echo $nonsimilarTrace "processes have different traces for FDR and UPPAAL" >> GenFiles/traceComparisonsAll
    fi    
     

#------------------------------------------------------------------------
#To update
#Removes all temporary file tmp, disable for debugging 
#rm */*/tmp





