-- This Haskell file defines a data type for TA, which is suitable for UPPAAL XML script.
-- Structure
    -- Example 1
    -- Example 2
    -- Example 3
    -- TA data type definition and additional part-examples 
    -- Other functions (mostly customise versions of show)
---------------------------------------------------------------------------------------------------

module TA where

import Data.List

-- Example 1--------------------------------------------------------------------------------------
ta1 :: TA
ta1 =  TA imports1 decls [template1] instTag1 system1 queries1 5
-- data TA = TA Imports DeclTag Template InstTag System Queries traceSize


-- Generate an XML file, ta1.xml
write1 =  writeFile "ta1.xml" (fileHeader ++ show ta1)


-- Example 2 -------------------------------------------------------------------------------------
ta2 :: TA
ta2 =  TA imports1 [declarationA] [templateA] [instantiationA] (System [instantiationA]) queries1 5

-- Generate an XML file, ta2.xml
write2 =  writeFile "ta2.xml" (fileHeader ++ show ta2)

-- Example of variable declarations
variableIDA  =  VariableID "startSTOP" [] 
variableIDB  =  VariableID "tock"    [] 
declarationA =  VariableDecl type1 [variableIDA, variableIDB]

-- Example for transition
transitionA =  Transition location1 locationB [labelA] []
transitionB =  Transition locationB locationB [labelB] [(nail1), (nail2)]

locationB =  Location "id2" "s2" EmptyLabel None


labelA = Sync variableIDA Ques
labelB = Sync variableIDB Excl

templateA :: Template
templateA =  Template  "tempA"  []  [] [location1, locationB] [] (Init location1)  [transitionA, transitionB]

instantiationA = Instantiation "pA" templateA []


-- Example 3 -------------------------------------------------------------------------------------
ta3 :: TA
ta3 =  TA imports1 [declarationB] [templateB] [instantiationB] (System [instantiationB]) queries1 5

-- Generate an XML file, ta3.xml
write3 =  writeFile "ta3.xml" (fileHeader ++ show ta3)

declarationB =  VariableDecl type1 [variableIDA, variableIDB, variableIDC, variableIDD]

variableIDC  =  VariableID "tick"        [] 
variableIDD  =  VariableID "finishID"    [] 

transitionC =  Transition locationB locationC [labelC] []
transitionD =  Transition locationC locationD [labelD] []


locationA =  Location "id1" "s1" EmptyLabel None
locationC =  Location "id3" "s3" EmptyLabel CommittedLoc
locationD =  Location "id4" "s4" EmptyLabel None

labelC = Sync variableIDC Excl
labelD = Sync variableIDD Excl

parameterA = Parameter (Type Meta   TypeBool) "n" []

templateB :: Template
templateB =  Template  "tempB"  [parameterA]  [] [locationA, locationB,locationC, locationD] 
                    [] (Init location1)  [transitionA, transitionB, transitionC, transitionD]

instantiationB = Instantiation "procA" templateB [Val 3]


---------------------------------------------------------------------------------------------------
-- Data type definition and examples 
---------------------------------------------------------------------------------------------------
-- Header of the UPPAAL XML script 
fileHeader = "<?xml version=\"1.0\" encoding=\"utf-8\"?> \n" ++
            "<!DOCTYPE nta PUBLIC '-//Uppaal Team//DTD Flat System 1.1//EN' 'http://www.it.uu.se/research/group/darts/uppaal/flat-1_2.dtd'>\n\n"




-- <!ELEMENT nta (imports?, declaration?, template+, instantiation?, system, queries?)>
data TA = TA Imports [Declaration] [Template] InstTag System Queries TraceSize

instance Show TA where 
        show (TA i d ts ins s q n) = "<nta>" ++ 
                                   "\n<declaration>\n" ++ ishowLines d   ++ 
                                   "\n int __reach__  = 0, __single__  = 0;     \n"              ++
                                   "// Needed for Uppaal to work correctly in the verification of reachability" ++
                                   "\n</declaration>"  ++ 
                                   "\n"                ++ ishowLines ts  ++ "\n"                 ++ 
                                   "\n<system>\n"      ++ ishowLines ins ++ "\n\n" ++            
                                   "\nsystem "         ++ show s         ++ ";\n</system>\n"     ++ 
                                   "\n<queries>\n"     ++ "<query>"      ++
                                   "<formula>A[] not deadlock \n</formula>" ++  
{--                                   "\n<comment>  The system is deadlock-free. \n</comment> "     ++
                                   "\n</query> "       ++ 
                                   "\n<query>"         ++
--                                "<formula> E&lt;&gt;  ((dp == 5)) \n</formula>"               ++       
--                                "<formula> E&lt;&gt;  ((dp == " ++ show n ++ ")) \n</formula>"             ++       
--}                                "\n<comment>  Is it deadlock free \n</comment> "    ++
                                   "\n</query> "       ++             
                                   "\n</queries>"      ++ 
                                   "\n</nta>"
          
          
-- <!ELEMENT template (name, parameter?, declaration?, location*, branchpoint*, init?, transition*)>
data Template =  Template Name Parameters [Declaration]  [Location]  [Branchpoint]  Init [Transition]
instance Show Template where
                        show (Template name par decls loc br init trans) = 
                                "// template for "   ++ name             ++ " begins \n"           ++
                                "\n <template>"      ++
                                "\n <name> "         ++ name             ++ "</name> \n"           ++
                                "\n <parameter> "    ++ ishowList par    ++ "</parameter>\n"  ++
                                "\n <declaration>\n" ++ ishowLines decls ++ "\n</declaration>\n\n" ++
                                ishowLines loc       ++            -- location have individual tag
                                "\n"                 ++ show init        ++  "\n"                  ++
                                ishowLines trans     ++            -- Also transition have individual tag 
                                " </template> \n"    ++
                                "// template for "   ++ name             ++ " ends\n"                                

-----------------------------------------------------------------------------------------------------
type TraceSize = Int

type Imports = [Char] 
imports1 = ""


-- Example
decls = [declaration1, declaration2, declaration3, declaration4]           

-- Example
template1 :: Template
template1 =  Template  "temp1"  parameters1  decls locationList branchPointlist1 init1 transitionList1

type InstTag = [Instantiation]
-- Example 
instTag1 :: InstTag
instTag1 = [instantiation1, instantiation2, instantiation3]


-- from the UPPAAL help menu
-- Parameters ::= [ Parameter (',' Parameter)* ]
type Parameters = [Parameter]

-- Example
parameters1 :: Parameters
parameters1 = [parameter1]


-- Parameter  ::= Type [ '&' ] ID ArrayDecl*
data Parameter = Parameter Type ID [ArrayDecl] | ParameterRef Type ID [ArrayDecl]
instance Show Parameter where
        show (Parameter    t id [])   = show t ++ " "  ++ id 
        show (ParameterRef t id [])   = show t ++ "& " ++ id 
        show (Parameter    t id [ad]) = show t ++ " "  ++ id ++ show ad
        show (ParameterRef t id [ad]) = show t ++ "& " ++ id ++ show ad

-- Example
parameter1, parameter2, parameter3 :: Parameter
parameter1 = Parameter (Type Meta   TypeBool)                 "p1" []
-- >> bool p1
parameter2 = Parameter (Type Meta   TypeInt)                  "p2" [(ArrayDecl [exp1])]
-- >> int p2[3+5]
parameter3 = Parameter (Type Meta   (TypeId "DefineType"))    "p3" [(ArrayDecl [exp1])] 
-- >> "DefineType" p3[3+5]


-- data Location = Location name label urgent committed  -- to add optional attribute position and Colour
data Location = Location ID Name Label LocType
instance Show Location where 
            show (Location id n l lt) =    "<location id=\"" ++ id  ++ "\" >   \n"    ++
                                            "<name> "         ++ n  ++ "</name>\n"    ++
                                            show l                  ++        "\n"    ++ 
                                            show lt                 ++ "\n</location> \n"

-- Example
location1, location2, location3 :: Location
location1 =  Location "id1" "s1" EmptyLabel UrgentLoc
-- >> <location id="id1" >   
-- >> <name> s1</name>
-- >> <label kind="invariant"> 7 </label>
-- >> <urgent/>
-- >> </location> 

location2 =  Location "id2" "s2" label1 None
-- >> <location id="id2" >   
-- >> <name> s1</name>
-- >> <label kind="invariant"> 7 </label>
-- >> <urgent/>
-- >> </location> 

location3 =  Location "id3" "s3" EmptyLabel CommittedLoc
-- >> <location id="id3" >   
-- >> <name> s1</name>
-- >> <label kind="invariant"> 7 </label>
-- >> <urgent/>
-- >> </location> 

-- Example
locationList = [location1, location2, location3]
-- >> <location id="id9" >   
-- >> <name> s1</name>
-- >> <label kind="invariant"> 7 </label>
-- >> <urgent/>
-- >> </location>
                                       

-- To consider mergin this into the template, to avoid new data.
data Init = Init Location
instance Show Init where
            show (Init (Location id _ _ _)) =  "<init ref=\"" ++ id ++ "\"/>"

-- Example
init1 :: Init
init1 =  Init location1
-- >> <init ref="id1"/>


data LocType = UrgentLoc | CommittedLoc | None
instance Show LocType where
        show UrgentLoc    = "<urgent/>"
        show CommittedLoc = "<committed/>"
        show None         = ""
        
-- Example
locType1 =  UrgentLoc
-- >> <urgent/>



--Sample label from the system        
-- <label kind="invariant" x="240" y="32">x&lt;=k</label>
-- To add optional position for the label
data Label = EmptyLabel 
           | Invariant    Expression 
           | Guard        Expression 
           | Update       [Expression] 
           | SelectLabel  [Expression] ID           TypeId
           | Sync         VariableID   Direction

instance Show Label where
        show EmptyLabel              = ""
        show (Invariant n )           = "<label kind=\"invariant\"> " ++ show n       ++ " </label>" 
        show (Guard     g )           = "<label kind=\"guard\"> "     ++ show g       ++ " </label>" 
        show (Update    es)           = "<label kind=\"assignment\">" ++ ishowList es ++ " </label>" 
        show (SelectLabel [] id typ) = "<label kind=\"select\"> "    ++ id     ++ ":" ++ show typ ++ "</label>"
        show (SelectLabel es id typ) = "<label kind=\"select\"> "    ++ id     ++ ":" ++ show typ ++ show es ++ 
                                        "</label>"
        show (Sync (VariableID id _) dir )    = "<label kind=\"synchronisation\"> "     ++ id ++ show dir ++ "</label>"

-- Example
label1, label2, label3, label4 :: Label

label1 = Invariant (exp3)
-- >> <label kind="invariant"> ck<=5 </label>

label2 = Update [(Val 3)]
-- >> <label kind="update"> 3 </label>

label3 = Sync (VariableID "up" []) Excl
-- >> <label kind="synchronisation"> up!</label>

label4 = SelectLabel [Val 1, Val 2, Val 3] "i" TypeInt
-- >> <label kind="select\> i:int[1,2,3]</label>

label5 = Sync (VariableID "down" []) Excl
-- >> 

-- From the BNF of UPPAAL
-- <!ELEMENT transition (source, target, label*, nail*)>
-- <!ATTLIST transition id  ID #IMPLIED
--                     x   CDATA #IMPLIED
--                     y   CDATA #IMPLIED
--                    color CDATA #IMPLIED>
-- <!ELEMENT source EMPTY>
-- <!ATTLIST source ref IDREF #REQUIRED>
-- <!ELEMENT target EMPTY>
-- <!ATTLIST target ref IDREF #REQUIRED>

data Transition = Transition Source Target [Label] [Nail]

type Source = Location
type Target = Location


instance Show Transition where
            show (Transition s t l n) = "\n<transition>" ++ 
                                        "\n<source ref=\""  ++ ref s          ++ "\"/>"  ++ 
                                        "\n<target ref=\""  ++ ref t          ++ "\"/>"  ++
                                        "\n"                ++ ishowLines l   ++
                                         showNail n      ++ 
                                        "\n</transition> \n"
                                            where ref (Location id _ _ _)  = id
                                                   
                                            
-- Example
transition1, transition2 :: Transition 
transition1 =  Transition location1 location2 [label3] [nail1]
transition2 =  Transition location2 location3 [label5] []


transitionList1 :: [Transition]
transitionList1 = [transition1, transition2]


data Direction = Ques | Excl
instance Show Direction where
        show Ques = "?"
        show Excl = "!"


-- Sample
-- <nail x="-34" y="17"/>
type Nail = (Int, Int)

-- Example 
nail1, nail2, nail3 :: Nail
nail1 = (1,3)
nail2 = (5,7)
nail3 = (9,11)

showNail :: [Nail] -> String
showNail    []     =  ""
showNail    (n:ns) = "\n<nail x=\"" ++ show (fst n) ++ "\" y=\"" ++ show (snd n) ++ "\"/> " ++ showNail ns

-- Example
shownail1 = showNail [nail1, nail2, nail3]
-- >> "<nail x=\"1\" y=\"3\"/>
-- >> <nail x=\"5\" y=\"7\"/>
-- >> <nail x=\"9\" y=\"11\"/>"
 

-- Definition from the BNF of UPPAAL
-- <!ELEMENT branchpoint EMPTY>
-- <!ATTLIST branchpoint id ID #REQUIRED
--		   x  CDATA #IMPLIED
--		   y  CDATA #IMPLIED
--		   color CDATA #IMPLIED>
-- Sample <branchpoint id="id3" x="40" y="230">
--		  </branchpoint>

data Branchpoint = Branchpoint ID
instance Show Branchpoint 
         where show (Branchpoint id) = "<branchpoint id=\"" ++ id ++ "\"> </branchpoint>"
            
-- Example 
branchpoint1, branchpoint2, branchpoint3 :: Branchpoint

branchpoint1 = Branchpoint "bp1"
-- >> <branchpoint id="bp1"> </branchpoint>
branchpoint2 = Branchpoint "bp2"
-- >> <branchpoint id="bp2"> </branchpoint>
branchpoint3 = Branchpoint "bp3"
-- >> <branchpoint id="bp3"> </branchpoint>

branchPointlist1 = []
branchPointlist2 = [branchpoint1, branchpoint2, branchpoint3]
            

-- From the BNF of UPPAAL
-- <!ELEMENT declaration (#PCDATA)>
{---------------------------- from the help menu
Declarations  ::= (VariableDecl | TypeDecl | Function | ChanPriority)*
VariableDecl  ::= Type VariableID (',' VariableID)* ';'
VariableID    ::= ID ArrayDecl* [ '=' Initialiser ]
Initialiser   ::= Expression
               |  '{' Initialiser (',' Initialiser)* '}'
TypeDecls     ::= 'typedef' Type ID ArrayDecl* (',' ID ArrayDecl*)* ';'
-- Function ::= Type ID '(' Parameters ')' Block 
-----------------------------------------------}

-- To consider this for improvement.
-- It seems like no need for a new type declarations, it is a list of declaration.
-- data Declarations      = Declarations [Declaration]
-- instance Show Declarations where 
--               show (Declarations decls) =  ishowLines decls
           
-- Example
-- declarations1, declarations2, declarations3 :: Declarations

declarations1 :: [Declaration]
declarations1 =  [declaration1] 
-- >> Type urgent chanvar1;

declarations2 ::  [Declaration]
declarations2 =  [declaration1, declaration2]
-- >> Type urgent chanvar1;
-- >> Type urgent chanvar2[3] = {1, 2, 3};
-- declarations3 =  Declarations [declaration1, declaration2, declaration3]

declarations3 :: [Declaration]
declarations3 = [declaration1, declaration2, declaration3]
-- >> Type urgent chanvar1;
-- >> Type urgent chanvar2[3] = {1, 2, 3};
-- >> Type meta int FunName(Type meta bool p1, Type meta int p2[3+5], Type meta "DefineType" p3[3+5])
-- >> {Type urgent chanvar1;
-- >> Type urgent chanvar2[3] = {1, 2, 3};
-- >> 3+5;}
               
-- Declartions
data Declaration  = VariableDecl    Type            [VariableID] 
                   | Function       Type            ID                          Parameters Block 
                   | ChanPriority   ChanExpDefOpt   [(ChanOrder,ChanExpDefOpt)]  


instance Show Declaration where 
            show (VariableDecl typ  varIDs)        = show typ ++ ishowList varIDs ++ ";"
            show (Function     typ id pars block)  = show typ ++ " " ++ id ++ "(" ++ ishowList pars ++ ")\n" 
                                                       ++ show block 
            show (ChanPriority ch chOrds)          = "chan priority " ++ show ch ++ showChOrd chOrds ++ ";"
                                                         where 
                                                            showChOrd [] = []
                                                            showChOrd ((x,y):chs) = show x ++ show y ++ showChOrd chs
--            show (TypeDecls    typ  Type [ID [ArrayDecl]]) = "typedef" ++ show typ ++ show id ++ ishowList arrayDecls ++ " " ++ (',' ID ArrayDecl*)* ';'
       
-- Example  
declaration1 =  VariableDecl type1 [variableID1, variableID3]
-- >> chan up;
                       
declaration2 =  VariableDecl type2 [variableID2]
-- >> Type urgent chanvar2[3] = {1, 2, 3};
                       
declaration3 =  Function type2 "FunName" parameters1 block1 

declaration4 =  VariableDecl type3 [(VariableID "ck" [])]
-- >> Type meta int FunName(Type meta bool p1, Type meta int p2[3+5], Type meta "DefineType" p3[3+5])
-- >> {Type urgent chanvar1;
-- >> Type urgent chanvar2[3] = {1, 2, 3};
-- >> 3+5;}

declarationList1 = [declaration1, declaration2]
-- >> [Type urgent chanvar1;,Type urgent chanvar2[3] = {1, 2, 3};]


-- VariableID    ::= ID ArrayDecl* [ '=' Initialiser ]
data VariableID = VariableID     ID [ArrayDecl] 
                | VariableIDInit ID [ArrayDecl]  Initialiser
      
-- Non array variable use empty array, that is not display in the declaration                
instance Show VariableID where
          show (VariableID      id [] )                    = id 
          show (VariableIDInit  id []       initialiser)   = id ++ " = " ++ show initialiser
          show (VariableID      id [aryDecls]            ) = id ++ show aryDecls 
          show (VariableIDInit  id [aryDecls] initialiser) = id ++ show aryDecls ++ " = " ++ show initialiser

-- Example          
variableID1 = VariableID "up" [] 
-- >> up

variableID3 = VariableID "down" []
-- >> down


variableID2 = VariableIDInit "var2" [ArrayDecl [(Val 3)]] initialiser3
-- >> var2[3] = {1, 2, 3}          
          
-- Initialiser   ::= Expression
--               |  '{' Initialiser (',' Initialiser)* '}'

data Initialiser  = Initialiser Expression
                  | MultInitialiser [Initialiser] 

instance Show Initialiser where
             show (Initialiser e) = show e
             show (MultInitialiser initialisers) = "{" ++ ishowList initialisers  ++ "}" 
             
-- Example 
initialiser1 = Initialiser (Val 5)
-- >> 5
  
initialiser2 = Initialiser (exp1) 
-- >> 3 + 5 
initialiser3 = MultInitialiser [(Initialiser $ Val 1), (Initialiser $ Val 2), (Initialiser $ Val 3)]  
-- >> {1, 2, 3}

-- Example
chanPriority1 = ChanPriority (Chanexpr (ChanID "ch")) [(Lessthan, (Chanexpr chanExpr1)),  (Lessthan, DefaultChan), 
                                  (Lessthan, (Chanexpr chanExpr2))]
-- >> chan priority ch < chID1 < default < chID2[3+5];

chanPriority2 = ChanPriority (Chanexpr (ChanID "a")) [(Comma, (Chanexpr chanExpr3)), (Lessthan, DefaultChan), 
                                                      (Lessthan, (Chanexpr (ChanID "b"))), 
                                                      (Comma, (Chanexpr (ChanID "e")))                  ] 
-- >> chan priority a, d[3] < default < b, e;

-- ChanPriority ::= 'chan' 'priority' ChanExpDefOpt [(ChanOrder, ChanExpDefOpt)] 
data ChanExpDefOpt = Chanexpr ChanExpr | DefaultChan  

instance Show ChanExpDefOpt where
        show (Chanexpr chExp) = show chExp
        show DefaultChan      = "default"
              
-- PriorityChanExp     = ChanOrder  ChanExpDefOpt
data ChanOrder = Comma | Lessthan
instance Show  ChanOrder where 
              show Comma  =  ", "
              show Lessthan = " < "

data ChanExpr = ChanID ID
              | ChanExpr ID Expression 
           
instance Show ChanExpr where 
            show (ChanID id)       = id
            show (ChanExpr id exp) = id ++ "[" ++ show exp ++ "]"
            
-- Example            
chanExpr1, chanExpr2, chanExpr3 :: ChanExpr
chanExpr1 = ChanID "chID1"
-- >> chID1
chanExpr2 = ChanExpr "chID2" exp1
-- >> chID2[3+5]
chanExpr3 = ChanExpr "d" (Val 3)
-- >> d[3]

--   Type from the UPPAAL application help menu
--   Type ::= Prefix TypeId
data Type = Type Prefix TypeId  -- deriving Show
instance Show Type where 
        show (Type p t) = show p ++ " " ++ show t


-- Example 
type1, type2, type3 :: Type
type1 = Type Meta TypeChan
-- >> chan
--type1 = Type prefix1 typeId1


type2 = Type Meta TypeInt
-- >> int

type3 = Type Meta TypeClock
-- >> clock

-- Prefix ::= 'urgent' | 'broadcast' | 'meta' | 'const'
data Prefix = Urgent | Broadcast | Meta | Const
instance Show Prefix where
    show Urgent    =  "urgent" 
    show Broadcast =  "broadcast"
    show Meta      =  ""            --"meta" 
    show Const     =  "const" 

-- Example
prefix1, prefix2 :: Prefix
prefix1 =  Meta
-- >> 

prefix2 =  Urgent
-- >> urgent

-- Type definition from the BNF of UPPAAL
-- TypeId        ::= ID | 'int' | 'clock' | 'chan' | 'bool'
--               |  'int' '[' Expression ',' Expression ']'
--               |  'scalar' '[' Expression ']'
--               |  'struct' '{' FieldDecl (FieldDecl)* '}'

data TypeId = TypeId ID | TypeInt | TypeClock | TypeChan | TypeBool
            |  ArrayInt Expression Expression
            |  Scalar   Expression
            |  Struct   [FieldDecl]

instance Show TypeId where
        show (TypeId   id)    = show id
        show TypeInt          = " int " 
        show TypeClock        = " clock " 
        show TypeChan         = " chan " 
        show TypeBool         = " bool "
        show (ArrayInt e1 e2) = " int     [" ++ show e1 ++ ", " ++ show e2 ++ "] "
        show (Scalar e)       = " scalar  [" ++ show e  ++ "] "
        show (Struct fds)     = " struct  {" ++ ishowList fds ++ "} "

                
-- Example
typeId1, typeId2, typeId3 :: TypeId
typeId1 = TypeInt
-- >> int

typeId2 = Struct fieldDeclList              
-- >>struct  {Type meta int a[3][5][6], b[5], c[9], Type meta int a[1], b[1][3][5], c[5][6]}

typeId3 = TypeChan
-- >> chan

--FieldDecl     ::= Type ID ArrayDecl* (',' ID ArrayDecl*)* ';'
data FieldDecl = FieldDecl Type [(ID, [ArrayDecl])] 

instance Show FieldDecl where
            show (FieldDecl t ns) = show t ++ " " ++ (sshow ns)

-- Example 
fieldDecl1 = FieldDecl type2 [("a", [ArrayDecl [Val 3, Val 5, Val 6]]), 
                              ("b", [ArrayDecl [Val 5]]), 
                              ("c", [ArrayDecl [Val 9]])]
                
fieldDecl2 = FieldDecl type2 [("a", [ArrayDecl [Val 1]]), 
                              ("b", [ArrayDecl [Val 1, Val 3, Val 5]]), 
                              ("c", [ArrayDecl [Val 5, Val 6 ]])]

-- Example
fieldDeclList = [fieldDecl1, fieldDecl2]
            
-- Function sshow use in the definition of show for FieldDecl
sshow :: [(ID, [ArrayDecl])] -> String

sshow []                  = ""
sshow ((s, (ns)):[])      = s ++ showArrayMD ns
sshow ((s, (ns)):ms)      = s ++ showArrayMD ns ++ ", " ++  sshow ms

sshow1 =  sshow [("a", [ArrayDecl [Val 1]]), 
                 ("b", [ArrayDecl [Val 1,  Val 3, Val 5]]), ("c", [ArrayDecl [Val 5, Val 6]])]


-- Function for displaying array declaration
showArrayMD :: [ArrayDecl] -> String
showArrayMD    []          =  ""
showArrayMD    (n:ns)      =  show n ++  showArrayMD ns

-- Example
showArrayMD1 = showArrayMD [ArrayDecl [Val 3, Val 3, Val 3]]


-- ArrayDecl ::= '[' <Expression> ']'
data ArrayDecl = ArrayDecl [Expression]

instance Show ArrayDecl where 
            show (ArrayDecl []) = ""
            show (ArrayDecl (e:es)) = "[" ++ show e ++ "]" ++ show (ArrayDecl (es))
            
-- Example
arrayDecl1 = ArrayDecl [(Val 5)]
-- >> [5]            


--    FieldInit ::=  <Initialiser> | ID ':'  <Initialiser>
data FieldInit = FieldInit Initialiser
               | FieldIDInit ID Initialiser
               
instance Show FieldInit where
            show (FieldInit init)      = show init
            show (FieldIDInit id init) = show id ++ ":" ++ show init

-- Example 
fieldInit1 = FieldInit initialiser1
-- >> 5

fieldInit2 = FieldInit initialiser2
-- >> 3+5

-- data Instantiation = Instantiation ID ID [Parameter]
data Instantiation = Instantiation ID Template [Expression]
-- [Parameter]
instance Show Instantiation where 
            show (Instantiation id1 (Template id2 _ _ _ _ _ _ ) es) = 
                id1 ++ " = " ++ id2 ++ "(" ++ ishowList es  ++ ");"
                    
-- Example                    
instantiation1, instantiation2, instantiation3 :: Instantiation                     
instantiation1 = Instantiation "p1" template1 [TrueExp]
instantiation2 = Instantiation "p2" template1 [TrueExp]
instantiation3 = Instantiation "p3" template1 [TrueExp]


instantiationList = [instantiation1, instantiation2, instantiation3] 


-- System definition
data System = System [Instantiation]
instance Show System where
           show (System ins) = ishowListSt (map (\(Instantiation id _ _) -> id) ins)
           
-- Example
system1 :: System
system1 =  System instantiationList


-- <!ELEMENT queries (query*)>
-- <!ELEMENT query (comment,property)>                    
type Queries = [Char]
queries1 :: Queries
queries1 = "Queries"


-- Defintion of statement
data Statement =  Blockstm Block
                | SemicolonStm 
                | ExprStm       Expression
                | ForLoop       Expression     Expression   Expression    Statement
                | Iteration     ID             Type         Statement
                | WhileLoop     Expression     Statement
                | DoWhile       Statement      Expression 
                | IfStm         Expression     Statement   
                | IfElseStm     Expression     Statement    Statement
                | ReturnStm     Expression

 
instance Show Statement where 
            show (Blockstm b)                       = show b 
            show SemicolonStm                       = ";"
            show (ExprStm    e)                     = show e ++ "; "
            show (ForLoop    exps1 exps2 exps3 stm) = "for(" ++ show exps1   ++  ";" ++ show exps2 ++ ";" ++ 
                                                         show exps3   ++ ")" ++ show stm
            show (Iteration  id    typ   stm)       = "for   (" ++ id ++ ":" ++ show typ ++ " ) " ++ show stm ++ "\n" 
            show (WhileLoop  exps  stm)             = "while (" ++ show exps ++ ")" ++ show stm
            show (DoWhile    stm   exps)            = "do "     ++ show stm  ++ "while (" ++ show exps ++ ") ;"
            show (IfStm      exps  stm )            = "if ("    ++ show exps ++ ")" ++ show stm  
            show (IfElseStm  exps  stm1  stm2)      = "if ("    ++ show exps ++ ") " ++  show stm1 ++ 
                                                       "\nelse " ++ show stm2
            show (ReturnStm  exp)                   = "return " ++ show exp ++ ";"
            

-- Example
statement1 = ExprStm exp1
-- >> 3+5;
statement2 = ForLoop   (AssgExp    (ExpID "i")          ASSIGNMENT  (Val 1)) 
                       (AssgExp    (ExpID "i")          MulAssg    (Val 2))   
                       (BinaryExp  (ExpID "i")          Lte        (Val 9))
                       (ExprStm    (AssgExp (ExpID "j") ASSIGNMENT (BinaryExp (ExpID "j") Add (Val 5))))
-- >> for (i=1;i*=2;i<=9)j=j+5;

statementList :: [Statement]
statementList =  [statement1, statement2]      


-- Block   ::= '{' Declarations Statement* '}'
data Block = Block [Declaration] [Statement]

instance Show Block where
        show (Block decl stm) = "{" ++ ishowLines decl ++ "\n" ++ ishowLines stm ++ "}"
        
-- Example
block1 = Block [declaration2] [(ReturnStm exp1)] 
-- >> {Type urgent chan"var1";
-- >> Type urgent chan"var2"[3] = { 1, 2, 3 };
-- >> 3+5;}
   
  
{-- Expression from the BNF of UPPAAL.
 Expression ::= ID
            |   NAT
            |   'true' 
            |   'false'
            |   ID '(' <ArgList> ')'
            |   <Expression> '[' <Expression> ']'
            |   '(' <Expression> ')' 
            |   <Expression> '++' 
            |  '++' <Expression>
            |   <Expression> '--' 
            |  '--' <Expression>
            |   <Expression> <AssignOp> <Expression>
            |   <UnaryOp> <Expression>
            |   <Expression> <Rel> <Expression>
            |   <Expression> <BinIntOp> <Expression>
            |   <Expression> <BinBoolOp> <Expression>
            |   <Expression> '?' <Expression> ':' <Expression>
            |   <Expression> '.' ID>
--}

data Expression =   ExpID           ID
                |   Val             Int
                |   ExpList         [Expression]
                |   Bracket         Expression 
                |   ExprPlusPlus    Expression 
                |   PlusPlusExpr    Expression 
                |   ExprMinusMinus  Expression 
                |   MinusMinusExpr  Expression 
                |   AssgExp         Expression  AssignOp        Expression
                |   UnaryExp        UnaryOp     Expression
                |   BinaryExp       Expression  BinOp           Expression
                |   IFExp           Expression  Expression      Expression
                |   DotExp          Expression  ID
                |   ExprArg         ID          ArgList
                |   ForallExp       ID          Type            Expression
                |   ExistsExp       ID          Type            Expression
                |   SumExp          ID          Type            Expression
                |   Deadlock
                |   TrueExp
                |   FalseExp
                


instance Show Expression  where 
               show (ExpID          id)         =  id  
               show (Val            n)          =  show n
               show (ExpList        es)         =  ishowList es
               show (Bracket        e)          =  "("        ++  show e  ++  ")" 
               show (ExprPlusPlus   e)          =  show e     ++ "++" 
               show (PlusPlusExpr   e)          =  "++"       ++  show e 
               show (ExprMinusMinus e)          =  show e     ++ "--"
               show (MinusMinusExpr e)          =  show e 
               show (AssgExp        e1 op e2)   =  show e1    ++  show op ++  show e2
               show (UnaryExp       op e    )   =  show op    ++  show e
               show (BinaryExp      e1 op e2)   =  show e1    ++  show op ++  show e2
               show (IFExp          e1 e2 e3)   =  show e1    ++  "?"     ++  show e2  ++ ":" ++  show e3
               show (DotExp         e  id   )   =  show e     ++  "."     ++  id
               show (ExprArg        id arg  )   =  show id    ++  "("     ++  show arg ++ ")"
               show (ForallExp      id typ e)   =  "forall("  ++  id      ++  ":"      ++ show typ ++ ")" ++ show e
               show (ExistsExp      id typ e)   =  "exists( " ++  id      ++  ":"      ++ show typ ++ ")" ++ show e
               show (SumExp         id typ e)   =  "sum("     ++  id      ++  ":"      ++ show typ ++ ")" ++ show e
               show Deadlock                    =  "deadlock" 
               show TrueExp                     =  "true"
               show FalseExp                    =  "false"


--Example
exp1 = BinaryExp (Val 3) Add (Val 5)
-- >> 3+5

exp2 = IFExp (Bracket (BinaryExp  (ExpID "v1") Lth        (Val 9)))
             (Bracket (AssgExp (ExpID "hs") ASSIGNMENT (BinaryExp (Val 11) Pow (Val 13))))
             (Bracket (AssgExp (ExpID "hs") MulAssg    (BinaryExp (Val 15) Mod (Val 17))))
-- >> (v1<9)?(hs=11^13):(hs*=15%17)

exp3 = BinaryExp (ExpID "ck") Lte (Val 5)
-- >> ck<=5

exp4 = BinaryExp (ExpID "n") Subt (Val 1)

-- From the UPPAAL help menu
-- "Boolean values are type compatible with integers. An integer value of 0 (zero) is evaluated to false and any other integer value is evaluated to true. The boolean value true evaluates to the integer value 1 and the boolean value false evaluates to the integer value 0. Notice: A comparison like 5 == true evaluates to false, since true evaluates to the integer value 1. This is consistent with C++."


--   AssignOp ::= ASSIGNMENT | '+=' | '-=' | '*=' | '/=' | '%=' 
--            | '|=' | '&=' | '^=' | '<<=' | '>>='

data AssignOp = ASSIGNMENT | AddAssg | SubAssg | MulAssg | DivAssg | ModAssg |
                    OrAssg | AndAssg | PowAssg | LthAssg | GthAssg 

instance Show AssignOp where
            show ASSIGNMENT = "="
            show AddAssg    = "+="
            show SubAssg    = "-="
            show MulAssg    = "*="
            show DivAssg    = "/="
            show ModAssg    = "%="
            show OrAssg     = "|="
            show AndAssg    = "&="
            show PowAssg    = "^="
            show LthAssg    = "<<="
            show GthAssg    = ">>="
            

-- Unary      ::= '+' | '-' | '!' | 'not'
data UnaryOp = Positive | Negative | Exclamation | Not

instance Show UnaryOp where 
        show Positive     = "+"
        show Negative     = "-"
        show Exclamation  = "!"
        show Not          = "not"


{--
Binary     ::= '<' | '<=' | '==' | '!=' | '>=' | '>'
            |  '+' | '-' | '*' | '/' | '%' | '&'
            |  '|' | '^' | '<<' | '>>' | '&&' | '||'
            |  '<?' | '>?' | 'or' | 'and' | 'imply
--}
data BinOp = Lth     | Lte  | Equal | NotEq  | Gte  | Gth 
           | Add     | Subt | Mul   | Div    | Mod  | Amp
           | Divisor | Pow  | ShifL | ShiftR | Land | LOR
           | LEQ     | GEQ  | OrExp | AndExp | ImplyExp

instance Show BinOp where 
        show Lth     = "&lt;" 
        show Lte     = "&lt;=" 
        show Equal   = "==" 
        show NotEq   = "!=" 
        show Gte     = "&gt;=" 
        show Gth     = "&gt;" 
        show Add     = "+"
        show Subt    = "-"
        show Mul     = "*"
        show Div     = "/"
        show Mod     = "%"
        show Amp     = "&"        
        show Divisor = "|"
        show Pow     = "^"
        show ShifL   = "&lt;&lt;"
        show ShiftR  = "&gt;&gt;"
        show Land    = "&&" 
        show LOR     = "||"
        show LEQ     = "&lt;?"     
        show GEQ     = "&gt;?"  
        show OrExp   = "or" 
        show AndExp  = "and" 
        show ImplyExp   = "imply"

--   ArgList ::= [ <Expression> ( ',' <Expression> )* ] 
type ArgList = [Expression] 


-----------------------------------------------------
-- iTypes
type Name = String 
type ID = String  

-- To consider adding the optional attributes
-- <name x="32" y="-16"> name </name>
-- <!ELEMENT name (#PCDATA)>
-- <!ATTLIST name x   CDATA #IMPLIED
--               y   CDATA #IMPLIED>


-----------------------------------------------------
-- iUtilities functions
-----------------------------------------------------
--  ishowList function            
ishowList :: Show a => [a] -> [Char]
ishowList    []     =  []
ishowList    [x]    =  show x  
ishowList    (x:xs) =  show x ++ ", " ++ ishowList xs                                

--Example 
s1 = ishowList [1..9]
-- >> "1, 2, 3, 4, 5, 6, 7, 8, 9"

--  ishowList function            
ishowLines :: Show a => [a] -> String
ishowLines    []     =  []
ishowLines    [x]    =  show x
ishowLines    (x:xs) =  show x ++ "\n" ++ ishowLines xs             

--Example 
is1 = ishowLines [1..9]
-- >> "1\n2\n3\n4\n5\n6\n7\n8\n9"


--  ishowLines function for            
ishowLinesSt :: [String] -> String
ishowLinesSt    []     =  []
ishowLinesSt    [x]    =  x
ishowLinesSt    (x:xs) =  x ++ "\n" ++ ishowLinesSt xs             


--  ishowList function for string            
ishowListSt :: [String] -> [Char]
ishowListSt    []     =  []
ishowListSt    [x]    =  x  
ishowListSt    (x:xs) =  x ++ ", " ++ ishowListSt xs                                

