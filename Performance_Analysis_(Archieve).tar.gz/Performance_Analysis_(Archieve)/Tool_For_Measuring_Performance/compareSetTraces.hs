-- Brief description: this program compares set of traces from FDR and UPPAAL

-----------------------------------------------------
import qualified Data.Set  as St
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import Data.List.Split as S
import System.Environment   
import System.Directory  
import System.IO  
import Data.List
import Data.Function 
import TA
import Control.Monad

-------------------------------------------------------------------------------------------------------------------------
main = do 
        -- Read the input files as argument, FDR trace, Uppaal trace, directory and process name
        [fFDR, fUPPAAL, dr, pName] <- getArgs
        tFDR                       <- readFile fFDR
        tUPPAAL                    <- readFile fUPPAAL        

        -- put the both results of comparison and monitors into files,
        sequence [(writeFile (dr ++ "/traceSetComparison")   ("\n\n"  ++  (fst (comparison tFDR tUPPAAL)))),
                  (writeFile (dr ++ "/monitor/traceForMonitor" ++  pName) (snd (comparison tFDR tUPPAAL)))]

        
--------------------------------------------------------------------------------------
-- Compares the traces and returns the result, pass or fail with the trace differences
comparison ::    String -> String -> (String, String)
comparison       s1        s2     =  
         if   (setFDR == setUPPAAL) then ((resInfoT ++ implication ++ detailsT), "")
         else ((resInfoF ++ implicationF ++ detailsF), traceDiff)
         where  
           setFDR      = traceSet (replace "itick"  "tick" s1)
           setUPPAAL   = traceSet s2
           traceSet s  = St.fromList (reverse (sortBy (compare `on` length) (lines s)))
           resInfoT    = "FDRtraces == UPPAALtraces"  -- = " ++ (show (setFDR == setUPPAAL))
           resInfoF    = "FDRtraces != UPPAALtraces"  -- = " ++ (show (setFDR == setUPPAAL))           
           -- difference between the traces
           traceDiff  = unlines (St.toList (St.difference setFDR setUPPAAL))
--                   traceDiff  = ishowListSt (St.toList (St.difference setFDR setUPPAAL))
           -- details for similar traces
           detailsT   = 
                "\n\nFDRtraces = \n{"                  ++ (ishowListSt $ St.toList  setFDR   ) ++ emptyTrace setFDR    ++
                "\n\nUPPAALtraces = \n{"               ++ (ishowListSt $ St.toList  setUPPAAL) ++ emptyTrace setUPPAAL ++
                "\n\n(FDRtraces \\ UPPAALtraces) = \n{"++ ( traceDiff                        ) ++ "}"++
                "\n\n(UPPAALtraces \\ FDRtraces) = \n{"++ ( 
                ishowListSt $ St.toList (St.difference setUPPAAL setFDR))++"}"
           
           -- details for traces that are not similar     
           detailsF     = 
                "\n\nFDRtraces = \n{"                  ++ (ishowListSt $ St.toList  setFDR   ) ++ emptyTrace setFDR    ++
                "\n\nUPPAALtraces = \n{"               ++ (ishowListSt $ St.toList  setUPPAAL) ++ emptyTrace setUPPAAL ++
--                "\n\nFDRtraces = \n{"                  ++ (ishowListSt $ St.toList  setFDR   )  ++", [] }"++
--                "\n\nUPPAALtraces = \n{"               ++ (ishowListSt $ St.toList  setUPPAAL)  ++", [] }"++
                "\n\n(FDRtraces \\ UPPAALtraces) = \n{"++ ( traceDiff                        )  ++"}"++
                "\n\n(UPPAALtraces \\ FDRtraces) = \n{"++ ( 
                ishowListSt $ St.toList (St.difference setUPPAAL setFDR))++"}"
                
           emptyTrace s = if null s then " [] }" else  ", [] }"   
                  
           implication  = "\nThis implies that set of traces for FDR contains set of traces of UPPAAL, and vice versa."

           implicationF = "\nThe following analysis provides evidence that traces of UPPAAL contains traces of FDR." 

-- replacing a word in string
replace old new = intercalate new . splitOn old
      
--- Example for the function replace
r = replace "itick"  "tick" "[e2] \n [e2, e1] \n [e2, e1, itick] \n [e2, e1, itick] \n [e2, e1, itick]"



